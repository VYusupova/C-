#define _POSIX_C_SOURCE 199309L
#include "../../inc/functions.h"

/* 3-хмерный массив фигур [номер фигуры][ориентация фигуры][массив с
 * координатами ячеек] */
const TCoords SHAPES[SHAPE_QUANTITY][SHAPE_ORIENTATIONS][CELLS] = {
    // I
    {{{1, 0}, {1, 1}, {1, 2}, {1, 3}},
     {{0, 2}, {1, 2}, {2, 2}, {3, 2}},
     {{3, 0}, {3, 1}, {3, 2}, {3, 3}},
     {{0, 1}, {1, 1}, {2, 1}, {3, 1}}},
    // J
    {{{0, 0}, {1, 0}, {1, 1}, {1, 2}},
     {{0, 1}, {0, 2}, {1, 1}, {2, 1}},
     {{1, 0}, {1, 1}, {1, 2}, {2, 2}},
     {{0, 1}, {1, 1}, {2, 0}, {2, 1}}},
    // L
    {{{0, 2}, {1, 0}, {1, 1}, {1, 2}},
     {{0, 1}, {1, 1}, {2, 1}, {2, 2}},
     {{1, 0}, {1, 1}, {1, 2}, {2, 0}},
     {{0, 0}, {0, 1}, {1, 1}, {2, 1}}},
    // O
    {{{0, 1}, {0, 2}, {1, 1}, {1, 2}},
     {{0, 1}, {0, 2}, {1, 1}, {1, 2}},
     {{0, 1}, {0, 2}, {1, 1}, {1, 2}},
     {{0, 1}, {0, 2}, {1, 1}, {1, 2}}},
    // S
    {{{0, 1}, {0, 2}, {1, 0}, {1, 1}},
     {{0, 1}, {1, 1}, {1, 2}, {2, 2}},
     {{1, 1}, {1, 2}, {2, 0}, {2, 1}},
     {{0, 0}, {1, 0}, {1, 1}, {2, 1}}},
    // T
    {{{0, 1}, {1, 0}, {1, 1}, {1, 2}},
     {{0, 1}, {1, 1}, {1, 2}, {2, 1}},
     {{1, 0}, {1, 1}, {1, 2}, {2, 1}},
     {{0, 1}, {1, 0}, {1, 1}, {2, 1}}},
    // Z
    {{{0, 0}, {0, 1}, {1, 1}, {1, 2}},
     {{0, 2}, {1, 1}, {1, 2}, {2, 1}},
     {{1, 0}, {1, 1}, {2, 1}, {2, 2}},
     {{0, 1}, {1, 0}, {1, 1}, {2, 0}}},
};

int GRAVITY_LEVEL[MAX_LEVEL + 1] = {56, 53, 50, 48, 46, 44, 42, 40, 38, 36, 32};

char game_get_block(GameInfo_t *obj, int row, int column) {
  return obj->board[obj->cols * row + column];
}

static void game_set_block(GameInfo_t *obj, int row, int column, char value) {
  obj->board[obj->cols * row + column] = value;
}

bool game_check(const GameInfo_t *obj, int row, int col) {
  return 0 <= row && row < obj->rows && 0 <= col && col < obj->cols;
}

static void game_put(GameInfo_t *obj, TShape block) {
  for (int i = 0; i < CELLS; i++) {
    TCoords cell = SHAPES[block.type][block.orientation][i];
    game_set_block(obj, block.position.row + cell.row,
                   block.position.col + cell.col, block.type + 1);
  }
}

static void game_remove(GameInfo_t *obj, TShape block) {
  for (int i = 0; i < CELLS; i++) {
    TCoords cell = SHAPES[block.type][block.orientation][i];
    game_set_block(obj, block.position.row + cell.row,
                   block.position.col + cell.col, TC_EMPTY);
  }
}

static bool game_fits(GameInfo_t *obj, TShape block) {
  for (int i = 0; i < CELLS; i++) {
    int r = block.position.row + SHAPES[block.type][block.orientation][i].row;
    int c = block.position.col + SHAPES[block.type][block.orientation][i].col;
    if (!game_check(obj, r, c) || TC_IS_FILLED(game_get_block(obj, r, c))) {
      return false;
    }
  }
  return true;
}

static int random_shape(void) { return rand() % SHAPE_QUANTITY; }

static void game_new_falling(GameInfo_t *obj) {
  obj->falling = obj->next;
  obj->next.type = random_shape();
  obj->next.orientation = 0;
  obj->next.position.row = 0;
  obj->next.position.col = obj->cols / 2 - 2;
}

static void game_do_gravity_tick(GameInfo_t *obj) {
  obj->ticks_till_gravity--;
  if (obj->ticks_till_gravity <= 0) {
    game_remove(obj, obj->falling);
    obj->falling.position.row++;
    if (game_fits(obj, obj->falling)) {
      obj->ticks_till_gravity = GRAVITY_LEVEL[obj->level];
    } else {
      obj->falling.position.row--;
      game_put(obj, obj->falling);
      game_new_falling(obj);
    }
    game_put(obj, obj->falling);
  }
}

static void game_move(GameInfo_t *obj, int direction) {
  game_remove(obj, obj->falling);
  obj->falling.position.col += direction;
  if (!game_fits(obj, obj->falling)) {
    obj->falling.position.col -= direction;
  }
  game_put(obj, obj->falling);
}

static void game_down(GameInfo_t *obj) {
  game_remove(obj, obj->falling);
  while (game_fits(obj, obj->falling)) {
    obj->falling.position.row++;
  }
  obj->falling.position.row--;
  game_put(obj, obj->falling);
  game_new_falling(obj);
}

static void game_rotate(GameInfo_t *obj, int direction) {
  game_remove(obj, obj->falling);
  while (true) {
    obj->falling.orientation =
        (obj->falling.orientation + direction) % SHAPE_ORIENTATIONS;
    if (game_fits(obj, obj->falling)) break;
    obj->falling.position.col--;
    if (game_fits(obj, obj->falling)) break;
    obj->falling.position.col += 2;
    if (game_fits(obj, obj->falling)) break;
    obj->falling.position.col--;
  }
  game_put(obj, obj->falling);
}

static void game_handle_move(GameInfo_t *obj, UserAction_t move) {
  switch (move) {
    case TM_LEFT:
      game_move(obj, -1);
      break;
    case TM_RIGHT:
      game_move(obj, 1);
      break;
    case TM_DROP:
      game_down(obj);
      break;
    case TM_CLOCK:
      game_rotate(obj, 1);
      break;
    default:
      break;
  }
}

static bool game_line_full(GameInfo_t *obj, int i) {
  for (int j = 0; j < obj->cols; j++) {
    if (TC_IS_EMPTY(game_get_block(obj, i, j))) return false;
  }
  return true;
}

static void game_shift_lines(GameInfo_t *obj, int r) {
  for (int i = r - 1; i >= 0; i--) {
    for (int j = 0; j < obj->cols; j++) {
      game_set_block(obj, i + 1, j, game_get_block(obj, i, j));
      game_set_block(obj, i, j, TC_EMPTY);
    }
  }
}

static int game_check_lines(GameInfo_t *obj) {
  int nlines = 0;
  game_remove(obj, obj->falling);
  for (int i = obj->rows - 1; i >= 0; i--) {
    if (game_line_full(obj, i)) {
      game_shift_lines(obj, i);
      i++;
      nlines++;
    }
  }
  game_put(obj, obj->falling);
  return nlines;
}

static void game_adjust_score(GameInfo_t *obj, int lines_cleared) {
  static const int line_multiplier[] = {0, 100, 300, 700, 1500};
  obj->points += line_multiplier[lines_cleared];
  obj->level = MIN(MAX_LEVEL, obj->points / POINTS_PER_LVL);
}

static bool game_game_over(GameInfo_t *obj) {
  bool over = false;
  game_remove(obj, obj->falling);
  for (int i = 0; i < 2; i++) {
    for (int j = 0; j < obj->cols; j++) {
      if (TC_IS_FILLED(game_get_block(obj, i, j))) {
        over = true;
      }
    }
  }
  game_put(obj, obj->falling);
  return over;
}

bool game_tick(GameInfo_t *obj, UserAction_t move) {
  game_do_gravity_tick(obj);
  game_handle_move(obj, move);
  int lines_cleared = game_check_lines(obj);
  game_adjust_score(obj, lines_cleared);
  return !game_game_over(obj);
}

void game_init(GameInfo_t *obj, int rows, int cols) {
  obj->rows = rows;
  obj->cols = cols;
  obj->board = malloc(rows * cols);
  memset(obj->board, TC_EMPTY, rows * cols);
  obj->points = 0;
  obj->level = 0;
  obj->ticks_till_gravity = GRAVITY_LEVEL[obj->level];
  srand(time(NULL));
  game_new_falling(obj);
  game_new_falling(obj);
  obj->next.position.col = obj->cols / 2 - 2;
}

GameInfo_t *game_create(int rows, int cols) {
  GameInfo_t *obj = malloc(sizeof(GameInfo_t));
  game_init(obj, rows, cols);
  return obj;
}

void game_destroy(GameInfo_t *obj) {
  free(obj->board);
  obj->board = NULL;
}

void game_delete(GameInfo_t *obj) {
  game_destroy(obj);
  free(obj);
}

void mssleep(int milliseconds) {
  struct timespec ts;
  ts.tv_sec = 0;
  ts.tv_nsec = milliseconds * 1000000;
  nanosleep(&ts, NULL);
}

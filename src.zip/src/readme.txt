Tetris BrickGame v1.0 by Julesnov
For gamers, by gamer

1. To install:
	- type 'make install'
	- specify a directory to install (if not specified than installation will start to ./build directory)
2. To uninstall:
	- type 'make uninstall'

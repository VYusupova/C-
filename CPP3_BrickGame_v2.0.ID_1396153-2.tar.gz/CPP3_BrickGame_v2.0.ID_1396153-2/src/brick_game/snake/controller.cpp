#include "include/controller.h"

#include <chrono>
#include <map>

/**
 * @file controller.cpp
 * @brief игровой контроллер
 */

namespace s21 {

/**
 * @brief возвращает ссылку на экземпляр класса Snake
 */
Snake& GameEngine::GetSnake() {
  static Snake snake;
  return snake;
}

/**
 * @brief возвращает ссылку на экземпляр класса GameEngine
 */
GameEngine& GameEngine::GetGameEngine() {
  static s21::GameEngine engine;
  return engine;
}

/**
 * @brief получает срез данных от объекта Snake
 */
GameInfo_t GameEngine::GetGameInfo() { return GetSnake().CollectGameInfo(); }

/**
 * @brief запускает новую игру и проводит инициализацию
 */
void GameEngine::StartNewGame() {
  Snake& snake = GetSnake();
  snake.NewGame();
  current_state_ = State::kPlay;
  last_update_time_ = std::chrono::steady_clock::now();
}

/**
 * @brief обрабатывает пользовательский ввод в зависимости от FSM
 */
void GameEngine::HandleInput(UserAction_t action) {
  Snake& snake = GetSnake();

  if (action == Terminate) {
    snake.GameOver();
    snake.QuitGame();
    current_state_ = State::kQuit;
    return;
  }

  switch (current_state_) {
    case State::kStart:
      if (action == Start) {
        StartNewGame();
      }
      break;
    case State::kPause:
      if (action == Start) {
        StartNewGame();
      } else if (action == Pause) {
        snake.UnSetPause();
        current_state_ = State::kPlay;
      }
      break;
    case State::kPlay:
      if (action == Start) {
        StartNewGame();
      } else if (action == Pause) {
        snake.SetPause();
        current_state_ = State::kPause;
      } else if (action == Action)
        snake.Move();
      else {
        ProcessDirectionInput(action);
      }
      break;
    case State::kQuit:
      break;
  }
}

/**
 * @brief устанавливает движение змейки на основе ввода
 */
void GameEngine::ProcessDirectionInput(UserAction_t action) {
  static const std::map<UserAction_t, std::pair<int, int>> directionMap = {
      {Left, {-1, 0}}, {Right, {1, 0}}, {Up, {0, -1}}, {Down, {0, 1}}};

  Snake& snake = GetSnake();
  auto it = directionMap.find(action);
  if (it != directionMap.end()) {
    snake.SetDirection(it->second.first, it->second.second);
  }
}
}  // namespace s21

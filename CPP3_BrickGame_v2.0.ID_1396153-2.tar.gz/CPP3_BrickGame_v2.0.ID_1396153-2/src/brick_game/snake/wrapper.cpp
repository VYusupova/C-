

#include "include/controller.h"

/**
 * @file wrapper.cpp
 * @brief обёртка для c++->c функций для соответствия спецификации
 */

/**
 * @brief Обрабатывает пользовательский ввод, передавая действие в игровой
 * движок.
 */
void userInput(UserAction_t action, bool hold __attribute__((unused))) {
  s21::GameEngine& engine = s21::GameEngine::GetGameEngine();
  engine.HandleInput(action);
}

/**
 * @brief Возвращает текущее состояние игры из движка.
 */
GameInfo_t updateCurrentState() {
  s21::GameEngine& engine = s21::GameEngine::GetGameEngine();
  return engine.GetGameInfo();
}
#ifndef FRONT_DEFINES_H
#define FRONT_DEFINES_H

/**
 * @file defines.h
 * @brief макросы текста и координат окон. Все имеют self-explanatory названия,
 * бриф не прилагаю
 */

#define MAINWINDOW_Y (LINES - 21) / 2 - 3
#define MAINWINDOW_X (COLS - 35) / 2
#define MAINWINDOW_Y_SIZE 24
#define MAINWINDOW_X_SIZE 35

#define BOARDWINDOW_Y MAINWINDOW_Y + 1
#define BOARDWINDOW_X (COLS - 35) / 2 + 1
#define BOARDWINDOW_Y_SIZE MAINWINDOW_Y_SIZE - 2
#define BOARDWINDOW_X_SIZE MAINWINDOW_X_SIZE - 11

#define CONTROLSWINDOW_Y MAINWINDOW_Y
#define CONTROLSWINDOW_X (COLS + 35) / 2 + 1
#define CONTROLSWINDOW_Y_SIZE MAINWINDOW_Y_SIZE - 15
#define CONTROLSWINDOW_X_SIZE MAINWINDOW_X_SIZE - 14

#define PAUSEWINDOW_Y (LINES - 20) / 2 + 6
#define PAUSEWINDOW_X (COLS - 35) / 2 + 3
#define PAUSEWINDOW_Y_SIZE MAINWINDOW_Y_SIZE - 18
#define PAUSEWINDOW_X_SIZE MAINWINDOW_X_SIZE - 15

// MENUS
#define CONTROL_TEXT "CONTROLS"
#define PAUSE_TEXT "P - PAUSE"
#define MOVE_TEXT "WASD - MOVE"
#define ROTATE_TEXT "SPACEBAR - ACTION"
#define QUIT_TEXT "Q - QUIT"
#define START_TEXT "E - START"
#define SCORE_TEXT "SCORE"
#define HIGHSCORE_TEXT "HIGHSCORE"
#define NEXT_TEXT "NEXT"
#define SPEED_TEXT "SPEED"
#define PAUSE_TITLE_TEXT "BrickGame"
#define PAUSE_ON_TEXT "Game Paused"
#define CONTINUE_BUTTON_TEXT "P - Continue"
#define GAMEOVER_TEXT "You lost"
#define NEW_GAME_BUTTON_TEXT "E - New Game"
#define QUIT_GAME_BUTTON_TEXT "Q - Quit"

#define PAUSE_ON "PAUSED"
#define PAUSE_OFF "      "
#define BOARD_SIZE_Y 20
#define BOARD_SIZE_X 10

#define NEXT_FIGURE_Y 4
#define NEXT_FIGURE_X 4

#define CONTROL_TEXT_Y 1
#define CONTROL_TEXT_X 2
#define PAUSE_TEXT_Y 3
#define PAUSE_TEXT_X 2
#define MOVE_TEXT_Y 4
#define MOVE_TEXT_X 2
#define ROTATE_TEXT_Y 5
#define ROTATE_TEXT_X 2
#define QUIT_TEXT_Y 6
#define QUIT_TEXT_X 2
#define START_TEXT_Y 7
#define START_TEXT_X 2

#define SCORE_NUMBER_Y 4
#define SCORE_NUMBER_X 28
#define HIGHSCORE_NUMBER_Y SCORE_NUMBER_Y + 2
#define HIGHSCORE_NUMBER_X SCORE_NUMBER_X

#define SPEED_NUMBER_Y 19
#define SPEED_NUMBER_X 28

#define PAUSE_TITLE_X 1
#define PAUSE_TITLE_Y 5

#define PAUSE_ON_Y 1
#define PAUSE_ON_X 5

#define CONTINUE_TEXT_Y 2
#define CONTINUE_TEXT_X 2

#define NEW_GAME_TEXT_Y 3
#define NEW_GAME_TEXT_X 2

#define QUIT_GAME_TEXT_Y 4
#define QUIT_GAME_TEXT_X 2
#define NO_INPUT 10

#endif  // FRONT_DEFINES_H
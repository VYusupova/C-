#include "front.h"

#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "defines.h"

/**
 * @file front.c
 * @brief ncurses представление
 */

UserAction_t getButton(int user_input) {
  UserAction_t currentAction = Pause;

  if (user_input == 87 || user_input == 119)  // w
    currentAction = Up;
  else if (user_input == 83 || user_input == 115)  // s
    currentAction = Down;
  else if (user_input == 65 || user_input == 97)  // a
    currentAction = Left;
  else if (user_input == 68 || user_input == 100)  // d
    currentAction = Right;
  else if (user_input == 81 || user_input == 113)  // q
    currentAction = Terminate;
  else if (user_input == 69 || user_input == 101)  // e
    currentAction = Start;
  else if (user_input == 112 || user_input == 80)  // p
    currentAction = Pause;
  else if (user_input == 32) {  // spacebar
    currentAction = Action;
  }
  return currentAction;
}

void endWindows(WindowsHolder* windows_holder) {
  delwin(windows_holder->board_window);
  delwin(windows_holder->controls_window);
  delwin(windows_holder->main_window);
  delwin(windows_holder->pause_window);
  endwin();
}

void startWindows(UserInputFunc userInput,
                  UpdateCurrentStateFunc updateCurrentState) {
  WindowsHolder windows_holder = {};
  initscr();
  noecho();
  cbreak();
  start_color();
  nodelay(stdscr, TRUE);
  keypad(stdscr, TRUE);
  curs_set(0);
  init_pair(1, COLOR_BLACK, COLOR_RED);
  init_pair(2, COLOR_BLACK, COLOR_GREEN);
  init_pair(3, COLOR_BLACK, COLOR_YELLOW);
  init_pair(4, COLOR_BLACK, COLOR_BLUE);
  init_pair(5, COLOR_BLACK, COLOR_MAGENTA);
  init_pair(6, COLOR_BLACK, COLOR_CYAN);
  init_pair(7, COLOR_BLACK, COLOR_WHITE);
  startMainWindow(&windows_holder);
  startBoardWindow(&windows_holder);
  startControlWindow(&windows_holder);
  do {
  } while (drawChanges(&windows_holder, userInput, updateCurrentState));
  endWindows(&windows_holder);
}
void sleepMilliseconds(unsigned int milliseconds) { napms(milliseconds); }

void startMainWindow(WindowsHolder* windows_holder) {
  windows_holder->main_window =
      newwin(MAINWINDOW_Y_SIZE, MAINWINDOW_X_SIZE, MAINWINDOW_Y, MAINWINDOW_X);
  box(windows_holder->main_window, 0, 0);
  mvwprintw(windows_holder->main_window, 3,
            MAINWINDOW_X_SIZE - strlen(SCORE_TEXT) - 1, SCORE_TEXT);
  mvwprintw(windows_holder->main_window, 5,
            MAINWINDOW_X_SIZE - strlen(HIGHSCORE_TEXT) - 1, HIGHSCORE_TEXT);

  mvwprintw(windows_holder->main_window, 18,
            MAINWINDOW_X_SIZE - strlen(SPEED_TEXT) - 1, SPEED_TEXT);
  refresh();
  wrefresh(windows_holder->main_window);
}

void startBoardWindow(WindowsHolder* windows_holder) {
  windows_holder->board_window = newwin(BOARDWINDOW_Y_SIZE, BOARDWINDOW_X_SIZE,
                                        BOARDWINDOW_Y, BOARDWINDOW_X);
  box(windows_holder->board_window, 0, 0);
  refresh();
  wrefresh(windows_holder->board_window);
}

void startControlWindow(WindowsHolder* windows_holder) {
  windows_holder->controls_window =
      newwin(CONTROLSWINDOW_Y_SIZE, CONTROLSWINDOW_X_SIZE, CONTROLSWINDOW_Y,
             CONTROLSWINDOW_X);
  box(windows_holder->controls_window, 0, 0);
  mvwprintw(windows_holder->controls_window, CONTROL_TEXT_Y, CONTROL_TEXT_X,
            CONTROL_TEXT);
  mvwprintw(windows_holder->controls_window, PAUSE_TEXT_Y, PAUSE_TEXT_X,
            PAUSE_TEXT);
  mvwprintw(windows_holder->controls_window, MOVE_TEXT_Y, MOVE_TEXT_X,
            MOVE_TEXT);
  mvwprintw(windows_holder->controls_window, ROTATE_TEXT_Y, ROTATE_TEXT_X,
            ROTATE_TEXT);
  mvwprintw(windows_holder->controls_window, QUIT_TEXT_Y, QUIT_TEXT_X,
            QUIT_TEXT);
  mvwprintw(windows_holder->controls_window, START_TEXT_Y, START_TEXT_X,
            START_TEXT);
  refresh();
  wrefresh(windows_holder->controls_window);
}

void drawField(WINDOW* window_ptr, int** field, int y, int x) {
  if (field == NULL) {
    return;
  }
  for (int i = 0; i < y; i++) {
    for (int j = 0; j < x; j++) {
      if (field[i][j]) {
        wattron(window_ptr, COLOR_PAIR(field[i][j]));
        mvwprintw(window_ptr, i + 1, (j + 1) * 2, "  ");
        wattroff(window_ptr, COLOR_PAIR(field[i][j]));
      } else {
        mvwprintw(window_ptr, i + 1, (j + 1) * 2, "  ");
      }
    }
  }
}

void drawNext(WINDOW* window_ptr, int** next, int y, int x) {
  if (next == NULL) {
    return;
  }

  for (int i = 0; i < y; i++)
    for (int j = 0; j < x; j++)
      if (next[i][j]) {
        wattron(window_ptr, COLOR_PAIR(next[i][j]));
        mvwprintw(window_ptr, 8 + i, 24 + (j + 1) * 2, "  ");
        wattroff(window_ptr, COLOR_PAIR(next[i][j]));
      } else {
        mvwprintw(window_ptr, 8 + i, 24 + (j + 1) * 2, "  ");
      }
}

void drawGameState(WindowsHolder* windows_holder, GameInfo_t* game_info) {
  if (game_info->field != NULL) {
    drawField(windows_holder->board_window, game_info->field, 20, 10);

    mvwprintw(windows_holder->main_window, SCORE_NUMBER_Y, SCORE_NUMBER_X,
              "%06i", game_info->score);
    mvwprintw(windows_holder->main_window, HIGHSCORE_NUMBER_Y,
              HIGHSCORE_NUMBER_X, "%06i", game_info->high_score);

    mvwprintw(windows_holder->main_window, SPEED_NUMBER_Y, SPEED_NUMBER_X,
              "%06i", game_info->speed);
    if (game_info->next != NULL) {
      mvwprintw(windows_holder->main_window, 7,
                MAINWINDOW_X_SIZE - strlen(NEXT_TEXT) - 1, NEXT_TEXT);
      drawNext(windows_holder->main_window, game_info->next, NEXT_FIGURE_Y,
               NEXT_FIGURE_X);
    }
    if (game_info->pause) {
      mvwprintw(windows_holder->main_window, 15,
                MAINWINDOW_X_SIZE - strlen(PAUSE_ON) - 1, PAUSE_ON);
    } else {
      mvwprintw(windows_holder->main_window, 15,
                MAINWINDOW_X_SIZE - strlen(PAUSE_OFF) - 1, PAUSE_OFF);
    }
    wrefresh(windows_holder->board_window);
    wrefresh(windows_holder->main_window);
  }
  refresh();
}

int handleExitConditions(GameInfo_t* game_info) {
  return !(!game_info->field && game_info->pause);
}

int drawChanges(WindowsHolder* windows_holder, UserInputFunc userInput,
                UpdateCurrentStateFunc updateCurrentState) {
  static char last_button = -1;
  static int same_button_count = 0;
  char button = getch();
  bool hold = false;

  if (button != -1) {
    if (button == last_button && last_button != -1) {
      same_button_count++;
      if (same_button_count >= 5) {
        hold = true;
      }
    } else {
      same_button_count = 1;
      last_button = button;
    }
    userInput(getButton(button), hold);
  }

  GameInfo_t game_info = updateCurrentState();
  drawGameState(windows_holder, &game_info);
  int code = handleExitConditions(&game_info);
  sleepMilliseconds(16);
  return code;
}
#ifndef FRONT_H
#define FRONT_H
#include <ncurses.h>

#include "../../include/library_spec.h"

typedef void (*UserInputFunc)(UserAction_t, bool);
typedef GameInfo_t (*UpdateCurrentStateFunc)(void);

typedef struct WindowsHolder {
  WINDOW* main_window;
  WINDOW* controls_window;
  WINDOW* board_window;
  WINDOW* pause_window;
} WindowsHolder;

void sleepMilliseconds(unsigned int milliseconds);
void startMainWindow(WindowsHolder* windows_holder);
void startBoardWindow(WindowsHolder* windows_holder);
void startControlWindow(WindowsHolder* windows_holder);
void drawField(WINDOW* window_ptr, int** field, int y, int x);
void drawNext(WINDOW* window_ptr, int** next, int y, int x);
void drawGameState(WindowsHolder* windows_holder, GameInfo_t* game_info);
int handleExitConditions(GameInfo_t* game_info);
void startWindows(UserInputFunc userInput,
                  UpdateCurrentStateFunc updateCurrentState);
int drawChanges(WindowsHolder* windows_holder, UserInputFunc userInput,
                UpdateCurrentStateFunc updateCurrentState);
typedef long unsigned int s21_size_t;

#endif  // FRONT_H
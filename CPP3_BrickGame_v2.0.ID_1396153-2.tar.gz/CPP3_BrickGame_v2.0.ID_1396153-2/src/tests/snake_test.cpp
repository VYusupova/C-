#include "../brick_game/snake/include/snake.h"

#include <gtest/gtest.h>

#include <chrono>
#include <memory>
#include <thread>

#include "../brick_game/snake/include/controller.h"
#include "../include/library_spec.h"

TEST(SnakeTest, Constructor) {
  s21::Snake snake;
  GameInfo_t game_info = snake.CollectGameInfo();
  ASSERT_NE(game_info.field, nullptr);
  ASSERT_EQ(game_info.score, 0);
  ASSERT_EQ(game_info.speed, 1);
  ASSERT_EQ(game_info.pause, 0);
}

TEST(SnakeTest, NewGame) {
  s21::Snake snake;
  snake.NewGame();
  GameInfo_t game_info = snake.CollectGameInfo();
  int body_count = 0;
  bool found_first = false;
  int row_with_snake = -1;

  for (int i = 0; i < 20 && !found_first; ++i) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[i][j] == 1) {
        if ((j > 0 && game_info.field[i][j - 1] == 1) ||
            (j < 9 && game_info.field[i][j + 1] == 1)) {
          found_first = true;
          row_with_snake = i;
          break;
        }
      }
    }
  }

  if (found_first) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[row_with_snake][j] == 1) {
        body_count++;
      }
    }
  }
  ASSERT_EQ(body_count, 4);
}

TEST(SnakeTest, GameOver) {
  s21::Snake snake;
  snake.NewGame();
  snake.GameOver();
  GameInfo_t game_info = snake.CollectGameInfo();
  ASSERT_EQ(game_info.pause, 1);
  bool all_ones = true;
  for (int i = 0; i < 20; ++i) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[i][j] != 1) {
        all_ones = false;
        break;
      }
    }
  }
  ASSERT_TRUE(all_ones);
}

TEST(GameEngineTest, StartNewGame) {
  s21::GameEngine& engine = s21::GameEngine::GetGameEngine();
  engine.HandleInput(Start);
  GameInfo_t game_info = engine.GetGameInfo();
  ASSERT_EQ(game_info.score, 0);
  ASSERT_EQ(game_info.speed, 1);
  ASSERT_EQ(game_info.pause, 0);
}

TEST(GameEngineTest, PauseGame) {
  s21::GameEngine& engine = s21::GameEngine::GetGameEngine();
  engine.HandleInput(Start);
  engine.HandleInput(Pause);
  GameInfo_t game_info = engine.GetGameInfo();
  ASSERT_EQ(game_info.pause, 1);
  engine.HandleInput(Pause);
  game_info = engine.GetGameInfo();
  ASSERT_EQ(game_info.pause, 0);
}

TEST(GameEngineTest, TerminateGame) {
  s21::GameEngine& engine = s21::GameEngine::GetGameEngine();
  engine.HandleInput(Start);
  engine.HandleInput(Terminate);
  GameInfo_t game_info = engine.GetGameInfo();
  ASSERT_EQ(game_info.pause, 1);
}

TEST(SnakeTest, FruitEatenTest) {
  s21::GameEngine& engine = s21::GameEngine::GetGameEngine();
  engine.HandleInput(Start);  // Начинаем новую игру

  GameInfo_t game_info = engine.GetGameInfo();

  // Находим фрукт на поле
  int fruit_x = -1, fruit_y = -1;
  bool found_fruit = false;
  for (int i = 0; i < 20 && !found_fruit; ++i) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[i][j] == 1) {
        // Проверяем, что вокруг нет других клеток со значением 1
        bool is_fruit = true;
        if (i > 0 && game_info.field[i - 1][j] == 1)
          is_fruit = false;  // Сверху
        if (i < 19 && game_info.field[i + 1][j] == 1)
          is_fruit = false;  // Снизу
        if (j > 0 && game_info.field[i][j - 1] == 1) is_fruit = false;  // Слева
        if (j < 9 && game_info.field[i][j + 1] == 1)
          is_fruit = false;  // Справа
        if (is_fruit) {
          fruit_x = j;
          fruit_y = i;
          found_fruit = true;
          break;
        }
      }
    }
  }

  ASSERT_TRUE(found_fruit) << "Fruit not found on the field";
  std::cout << "Fruit found at (" << fruit_x << ", " << fruit_y << ")"
            << std::endl;
  int head_x = 5;
  int head_y = 10;
  game_info = engine.GetGameInfo();
  ASSERT_EQ(game_info.field[head_y][head_x], 1)
      << "Snake head not at expected position (5, 10)";

  // Сохраняем начальные параметры
  int initial_score = game_info.score;
  int initial_snake_length = 0;
  for (int i = 0; i < 20; ++i) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[i][j] == 1) {
        initial_snake_length++;
      }
    }
  }

  int max_steps = 100;
  int steps = 0;
  while (head_x != fruit_x || head_y != fruit_y) {
    if (steps >= max_steps) {
      FAIL() << "Failed to reach fruit after " << max_steps << " steps.";
      break;
    }

    // Выбираем направление
    if (head_x < fruit_x) {
      engine.HandleInput(Right);
      head_x += 1;  // Предполагаем, что движение вправо успешно
    } else if (head_x > fruit_x) {
      engine.HandleInput(Left);
      head_x -= 1;  // Предполагаем, что движение влево успешно
    } else if (head_y < fruit_y) {
      engine.HandleInput(Down);
      head_y += 1;  // Предполагаем, что движение вниз успешно
    } else if (head_y > fruit_y) {
      engine.HandleInput(Up);
      head_y -= 1;  // Предполагаем, что движение вверх успешно
    }

    engine.HandleInput(Action);
    game_info = engine.GetGameInfo();

    for (int i = 0; i < 20; ++i) {
      for (int j = 0; j < 10; ++j) {
        if (game_info.field[i][j] == 1) {
          std::cout << "*";

        } else
          std::cout << " ";
      }
      std::cout << std::endl;
    }
  }

  // Проверяем, что фрукт съеден
  game_info = engine.GetGameInfo();
  ASSERT_EQ(game_info.score, initial_score + 1)
      << "Score did not increase by 10";
  ASSERT_EQ(game_info.speed, 1 + (initial_score + 1) / 50)
      << "Speed not updated correctly";

  // Проверяем, что змейка выросла
  int new_snake_length = 0;
  for (int i = 0; i < 20; ++i) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[i][j] == 1) {
        new_snake_length++;
      }
    }
  }
  ASSERT_EQ(new_snake_length, initial_snake_length + 1)
      << "Snake length did not increase";

  // Проверяем, что новый фрукт заспавнился
  found_fruit = false;
  for (int i = 0; i < 20 && !found_fruit; ++i) {
    for (int j = 0; j < 10; ++j) {
      if (game_info.field[i][j] == 1) {
        bool is_fruit = true;
        if (i > 0 && game_info.field[i - 1][j] == 1) is_fruit = false;
        if (i < 19 && game_info.field[i + 1][j] == 1) is_fruit = false;
        if (j > 0 && game_info.field[i][j - 1] == 1) is_fruit = false;
        if (j < 9 && game_info.field[i][j + 1] == 1) is_fruit = false;
        if (is_fruit) {
          found_fruit = true;
          break;
        }
      }
    }
  }
  ASSERT_TRUE(found_fruit) << "New fruit did not spawn";
}

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
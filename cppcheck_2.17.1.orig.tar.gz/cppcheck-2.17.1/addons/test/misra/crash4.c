
struct ConDesDesc {
    unsigned   Order;
    unsigned   Import;
};

// cppcheck-suppress misra-config
static ConDesDesc ConDes[CD_TYPE_COUNT] = {
    { 0, 0 },
    { 0, 0 },
};

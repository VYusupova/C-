// 13140
#line 78 "tmp.h"
typedef struct
{
int vara [30] ;
int varb [5] ;
} S0 ;



typedef struct
{
bool var1 ;
S2 var2 ;
S2 var3 ;
S2 var4 ;
short var5 ;
short var6 ;
S1 var7 ;
S1 var8 ;
S1 var9 ;
S1 var10 ;
S1 var11 ;
float var12 ;
short var13 [ 3 ] ;
} S3 ;

#line 33 "tmp.c"
static const S3 s3 =
{
0 ,
{ 0, 0 } ,
} ;
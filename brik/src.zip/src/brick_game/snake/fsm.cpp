#include "../../inc/snake/fsm.hpp"

namespace s21 {

UserAction_t fsm::get_signal(int user_input) {
    UserAction_t action = Start; // default value

    switch (user_input) {
        case KEY_UP:
            action = Up;
            break;
        case KEY_DOWN:
            action = Down;
            break;
        case KEY_LEFT:
            action = Left;
            break;
        case KEY_RIGHT:
            action = Right;
            break;
        case ESCAPE:
            action = Terminate;
            break;
        case ENTER_KEY:
            action = Start;
            break;
        case SPACE:
            action = Action;
            break;
        case PAUSE_p:
        case PAUSE_P:
            action = Pause;
            break;
        default:
            break;
    }
    return action;
}

void fsm::sigact() {
    if (!userAct || !gamestats || !state) return;

    print_stats(game);

    switch (*state) {
        case START:
            started();
            break;
        case SPAWN:
            spawned();
            break;
        case MOVING:
            moved();
            break;
        case SHIFTING:
            shifted();
            break;
        case ATTACHING:
            attach();
            break;
        case GAMEOVER:
            game_over();
            break;
        case EXIT:
            // Cleanup logic here
            break;
        default:
            break;
    }
}

void fsm::started() {
    *state = SPAWN;
    
    // Initialize snake game state
    if (game) {
        game->score = 0;
        game->level = 1;
        game->speed = 1;
        game->pause = 0;
        
        // Clear game field
        for (int i = 0; i < FIELD_N; ++i) {
            for (int j = 0; j < FIELD_M; ++j) {
                game->field[i][j] = 0;
            }
        }
    }
    
    // Initialize snake object would be done elsewhere
    snake::Snake(); // This should be called in constructor, not here
}

void fsm::spawned() {
    if (!game) return;
    
    // Spawn initial fruit and setup snake
    snake::SpawnFruit(); // This should be called on snake object
    
    *state = MOVING;
}

void fsm::moved() {
    if (!game || !userAct) return;
    
    // Handle movement based on user action
    switch (*userAct) {
        case Up:
        case Down:
        case Left:
        case Right:
            // Change snake direction
            snake::changeDirection(...);
            break;
        case Pause:
            SetPause();
            break;
        case Action:
            // Handle special action if needed
            break;
        default:
            break;
    }
    
    // Process game timer and movement
    if (ProcessGameTimer() == 0) {
        // Move snake
        snake::move();
        
        // Check for collisions
         if (snake::checkCollision()) {
             *state = GAMEOVER;
             return;
         }
        
        // Check for fruit eating
         if (fruit eaten) {
             *state = ATTACHING;
         }
    }
}

void fsm::shifted() {
    // Handle shifting state (if needed for snake)
    // For snake game, this might not be used, but keeping for consistency
    
    *state = MOVING;
}

void fsm::attach() {
    if (!game) return;
    
    // Handle fruit attachment/growth
     snake::FruitEat(...);
     game->score += 1;
    
    // Check if level should increase
     if (game->score % 5 == 0 && game->level < MAX_LEVEL) {
         game->level++;
         game->speed = game->level;
     }
    
    *state = MOVING;
}

void fsm::game_over() {
    if (game) {
        // Update high score if needed
        if (game->score > game->high_score) {
            game->high_score = game->score;
        }
    }
    
    // Wait for user input to restart or exit
    if (userAct && *userAct == Start) {
        *state = START;
    } else if (userAct && *userAct == Terminate) {
        *state = EXIT;
    }
}

void fsm::Move() {
    // Implementation for snake movement
}

void fsm::NewGame() {
    *state = START;
    started();
}

void fsm::GameOver() {
    *state = GAMEOVER;
    game_over();
}

void fsm::QuitGame() {
    *state = EXIT;
}

void fsm::SetPause() {
    if (game) {
        game->pause = 1;
    }
}

void fsm::UnSetPause() {
    if (game) {
        game->pause = 0;
    }
}

int fsm::ProcessGameTimer() {
    if (!game) return 1;
    
    // Simple timer implementation based on speed
    static int timer = 0;
    timer++;
    
    int speed_delay = SPEED / (game->speed > 0 ? game->speed : 1);
    
    if (timer >= speed_delay) {
        timer = 0;
        return 0; // Time to process movement
    }
    
    return 1; // Wait more
}

} // namespace s21

#include <iostream.h>
#include <vector>
#include "../inc/BrickGame.h"
#include "../../inc/snake/backend.hpp"
#include <algorithm>
#include <random>

namespace s21 {

snake::Snake() {
    game.field = new int*[FIELD_N];
    for (int i = 0; i < FIELD_N; ++i) {
      game.field[i] = new int[FIELD_M]{0};
    }
    copy.field = new int*[FIELD_N];
    for (int i = 0; i < FIELD_N; ++i) {
      copy.field[i] = new int[FIELD_M]{0};
    }
    game.next = NULL;
    game.pause = 0;
    game.score = 0;
    game.speed = 1;
    game.high_score = 0;
    //shared_data_ptr_ = NULL;
    copy.next = NULL;
    //LoadHighScore();
}

void snake::FreeGameMemory(GameInfo_t* game) {
	if(!game || !game->field) {
		return;
	}

	for(int i = 0; i < FIELD_N; i++) {
		delete[] game->field[i];
	}
	delete[] game->field;
	game->field = nullptr;
}

snake::~Snake() {
	FreeGameMemory(&game);
	FreeGameMemory(&copy);
}

void snake::snake_init() : direction(1) {
	int head_x = FIELD_N / 2;
	int head_y = FIELD_M / 2;
	body.emplace_back(head_x, head_y);  // Голова
  for (int i = 0; i < 4; ++i) {
    snake_body_.push_back({head_x - i, head_y});
  }
}

void snake::move() {
	auto newHead = body.front();
	switch(direction) {
		case 0:
			newHead.second--;
		break;
		case 1:
			newHead.first++;
		break;
		case 2:
			newHead.second++;
		break;
		case 3:
			newHead.first--;
		break;
	}
	body.insert(body.begin(), newHead);

	if(!needsToGrow) {
		body.pop_back();
	} else {
		needsToGrow = false;
	}
}

bool snake::checkCollision() {
	const auto head = body.front();
	return std::any_of(body.begin() + 1, body.end(), [&head](const auto &segment){ //умнейшая разработка алгоритмов
		return head == segment;
	});
	return head.first < 0 || head.first >= FIELD_N || head.second < 0 || head.second >= FIELD_M;
}

void snake::changeDirection(int newDir) {
	if(abs(newDir - direction) != 2) {
		direction = newDir;
	}
}

void snake::SpawnFruit() {
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> x_dist(0, FIELD_N - 1);
  std::uniform_int_distribution<int> y_dist(0, FIELD_M - 1);

  int fruit_x, fruit_y;
  do {
    fruit_x = x_dist(gen);
    fruit_y = y_dist(gen);
  } while (game.field[fruit_y][fruit_x] != 0);

  game.field[fruit_y][fruit_x] = 3;
}

void snake::FruitEat(int fruit_x, int fruit_y) {
  if (snake_body_.front().first == fruit_x &&
      snake_body_.front().second == fruit_y) {
		game.score += 1;
		needsToGrow = true;
	}
	if(game.speed != 10) {
	game.speed = 1 + game.score / 5;
	}
	SpawnFruit();
}

}

#include "../../inc/snake/backend.hpp"
#include "../../inc/BrickGame.h"

namespace s21 {

class SnakeGameAdapter {
private:
    snake game_instance;
    GameInfo_t game_state;
    
public:
    SnakeGameAdapter() {
        // Инициализация состояния игры для змейки
        game_state.field = new int*[FIELD_N];
        for (int i = 0; i < FIELD_N; ++i) {
            game_state.field[i] = new int[FIELD_M]{0};
        }
        game_state.score = 0;
        game_state.high_score = 0;
        game_state.level = 1;
        game_state.speed = 1;
        game_state.pause = 0;
    }
    
    ~SnakeGameAdapter() {
        // Освобождение памяти
        for (int i = 0; i < FIELD_N; i++) {
            delete[] game_state.field[i];
        }
        delete[] game_state.field;
    }
    
    GameInfo_t* getGameState() { return &game_state; }
    
    void handleInput(UserAction_t action) {
        // Преобразование UserAction_t в направление для змейки
        switch (action) {
            case Up: game_instance.changeDirection(0); break;
            case Right: game_instance.changeDirection(1); break;
            case Down: game_instance.changeDirection(2); break;
            case Left: game_instance.changeDirection(3); break;
            case Pause: 
                game_state.pause = !game_state.pause;
                break;
            default: break;
        }
    }
    
    void update() {
        if (!game_state.pause) {
            game_instance.move();
            // Обновление состояния игры на основе состояния змейки
            updateGameField();
        }
    }
    
private:
    void updateGameField() {
        // Очистка поля
        for (int i = 0; i < FIELD_N; ++i) {
            for (int j = 0; j < FIELD_M; ++j) {
                game_state.field[i][j] = 0;
            }
        }
        
        // Отрисовка змейки на поле
        auto body = game_instance.getBody();
        for (const auto& segment : body) {
            if (segment.first >= 0 && segment.first < FIELD_M && 
                segment.second >= 0 && segment.second < FIELD_N) {
                game_state.field[segment.second][segment.first] = 1; // Тело змейки
            }
        }
        
        // Обновление счета и других параметров
        game_state.score = game_instance.getLength() - 4; // Начальная длина 4
    }
};

// Глобальный экземпляр адаптера (в пределах файла)
static SnakeGameAdapter* snake_adapter = nullptr;

// Функции для интеграции с существующей архитектурой
void initializeSnakeGame() {
    if (!snake_adapter) {
        snake_adapter = new SnakeGameAdapter();
    }
}

GameInfo_t* getSnakeGameState() {
    return snake_adapter ? snake_adapter->getGameState() : nullptr;
}

void handleSnakeInput(UserAction_t action) {
    if (snake_adapter) {
        snake_adapter->handleInput(action);
    }
}

void updateSnakeGame() {
    if (snake_adapter) {
        snake_adapter->update();
    }
}

} // namespace s21

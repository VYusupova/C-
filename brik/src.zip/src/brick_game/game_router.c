#include "../inc/BrickGame.h"
#include "../inc/defines.h"
#include "../inc/tetris/fsm.h"

// Внешние функции из тетриса и змейки
extern void tetris_userInput(UserAction_t action, bool hold);
extern GameInfo_t tetris_updateCurrentState();

//extern void snake_userInput(UserAction_t action, bool hold);
//extern GameInfo_t snake_updateCurrentState();

// Текущий тип игры (локальная переменная)
static GameType_t current_game_type = GAME_TETRIS;

void userInput(UserAction_t action, bool hold) {
    switch (current_game_type) {
        case GAME_TETRIS:
            tetris_userInput(action, hold);
            break;
        case GAME_SNAKE:
            //snake_userInput(action, hold);
            break;
        default:
            break;
    }
}

GameInfo_t updateCurrentState() {
  GameInfo_t game = {0};
    switch (current_game_type) {
        case GAME_TETRIS:
            game = tetris_updateCurrentState();
        case GAME_SNAKE:
            //return snake_updateCurrentState();
            break;
    }
    return game;
}

void setCurrentGameType(GameType_t game_type) {
    current_game_type = game_type;
    
    // Инициализируем выбранную игру
    switch (game_type) {
        case GAME_TETRIS:
            initialize_tetris();
            break;
        case GAME_SNAKE:
            //initialize_snake();
            break;
        default:
            break;
    }
}

// Функция для получения текущего типа игры (для frontend)
GameType_t getCurrentGameType() {
    return current_game_type;
}

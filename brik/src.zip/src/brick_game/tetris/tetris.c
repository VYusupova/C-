#include "../../inc/tetris/tetris.h"

#include <stdlib.h>
#include <time.h>

// Преобразование из tetrisInfo_t в GameInfo_t
void tetrisInfo_to_GameInfo(const tetrisInfo_t* src, GameInfo_t* dest) {
    if (!src || !dest) return;
    
    // Копируем основные поля
    dest->score = src->score;
    dest->high_score = src->high_score;
    dest->level = src->level;
    dest->speed = src->speed;
    dest->pause = src->pause;
    
    // Копируем игровое поле
    for (int i = 0; i < FIELD_N; i++) {
        for (int j = 0; j < FIELD_M; j++) {
            if (dest->field && i < FIELD_N && j < FIELD_M) {
                dest->field[i][j] = src->field[i][j];
            }
        }
    }
}

// Преобразование из GameInfo_t в tetrisInfo_t  
void GameInfo_to_tetrisInfo(const GameInfo_t* src, tetrisInfo_t* dest) {
    if (!src || !dest) return;
    
    // Копируем основные поля
    dest->score = src->score;
    dest->high_score = src->high_score;
    dest->level = src->level;
    dest->speed = src->speed;
    dest->pause = src->pause;
    
    // Копируем игровое поле
    for (int i = 0; i < FIELD_N; i++) {
        for (int j = 0; j < FIELD_M; j++) {
            if (src->field && i < FIELD_N && j < FIELD_M) {
                dest->field[i][j] = src->field[i][j];
            }
        }
    }
}

// Инициализация адаптера для тетриса
void init_tetris_game_adapter(tetrisInfo_t* game, figura_t* fnow, figura_t* fnext) {
    if (game) {
        game->fnow = fnow;
        game->fnext = fnext;
    }
}


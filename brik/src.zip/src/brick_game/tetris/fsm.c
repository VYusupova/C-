#include "../../inc/tetris/fsm.h"
#include "../../inc/tetris/tetris_backend.h"
#include "../../inc/Brick_frontend.h"
#include "../../inc/tetris/tetris.h"

// This is a finite state machine realisation based on switch-case statement.
/*

    States are checked in order specified in function sigact().
    It enters a state-case which it corresponds to, where begins another
switch-case statement. Inner switch-case statement is looking for a signal given
by get_signal(). After finding it makes some action and switches state to the
next one.

    Pros:
        1) Less memory usage.
    Cons:
        1) A lot of codelines.
*/

UserAction_t get_signal(int user_input) {
  UserAction_t action = Start;

  switch (user_input) {
    case KEY_UP:
      action = Up;
      break;
    case KEY_DOWN:
      action = Down;
      break;
    case KEY_LEFT:
      action = Left;
      break;
    case KEY_RIGHT:
      action = Right;
      break;
    case ESCAPE:
      action = Terminate;
      break;
    case ENTER_KEY:
      action = Start;
      break;
    case SPACE:
      action = Action;
      break;
    case PAUSE_p:
    case PAUSE_P:
      action = Pause;
      break;
    default:
      break;
  }
  return action;
}

void shifted(fsm_state_t *state, figura_t *f, tetrisInfo_t *game) {
  if (!collision_down(f, game)) {
    refresh_figure(f, 0, 1);
    *state = MOVING;
  } else {
    *state = ATTACHING;
  }
}

void rotate(figura_t *f, tetrisInfo_t *gb) {
  hide_figure(f);
  rotate_figure(f, gb);
  show_figure(f);
}

void started(const UserAction_t *userAct, tetrisInfo_t *game,
             fsm_state_t *state) {
  switch (*userAct) {
    case Start:
      init_game(game);
      refresh_game_field((GameInfo_t*)game); // приведение типов структур
      init_figura(game->fnow);
      init_figura(game->fnext);
      *state = SPAWN;
      break;
    case Terminate:
      *state = EXIT;
      break;
    default:
      break;
  }
}

void spawned(tetrisInfo_t *gb, fsm_state_t *state) {
  spawn_new_figure(gb->fnow, gb->fnext);
  hide_figure(gb->fnext);
  init_figura(gb->fnext);
  show_figure(gb->fnext);
  show_figure(gb->fnow);
  *state = MOVING; //
}

void attach(fsm_state_t *state, tetrisInfo_t *game, const figura_t *f) {
  if (collision_up(f/*, game*/)) {
    *state = GAMEOVER;
  } else
    *state = SPAWN;
  figura_game_field(game);
  //score(game);
  refresh_game_field((GameInfo_t*)game);
}

void moved(const UserAction_t *userAct, fsm_state_t *state, tetrisInfo_t *game,
           figura_t *fnow) {
  switch (*userAct) {
    case Up:
      while (*state != ATTACHING) {
        shifted(state, fnow, game);
      }
      break;
    case Left:
      if (!collision_left(game->fnow, game)) refresh_figure(game->fnow, -1, 0);
      *state = SHIFTING;
      break;
    case Right:
      if (!collision_right(game->fnow, game)) refresh_figure(game->fnow, 1, 0);
      *state = SHIFTING;
      break;
    case Down:
      shifted(state, fnow, game);
      shifted(state, fnow, game);
      break;
    case Action:
      rotate(fnow, game);
      *state = SHIFTING;
      break;
    case Pause:
      *state = SHIFTING;
      game->pause = 1;
      print_stats((GameInfo_t*)game); //
      while (game->pause) {
        UserAction_t action = get_signal(GET_USER_INPUT);
        if (action == Pause) game->pause = 0;
        if (action == Start) game->pause = 0;
        if (action == Terminate) {
          game->pause = 0;
          *state = EXIT;
        }
      }
      print_stats((GameInfo_t*)game);
      refresh_game_field((GameInfo_t*)game);
      refresh_figure(game->fnow, 0, 0);
      break;
    case Terminate:
      *state = EXIT;
      break;
    default:
      *state = SHIFTING;
      break;
  }
}

void sigact(const UserAction_t *userAct, fsm_state_t *state,
            tetrisInfo_t *gamestats, figura_t *fnow) {
  print_stats((GameInfo_t*)gamestats);
  switch (*state) {
    case START:
      started(userAct, gamestats, state);
      break;
    case SPAWN:
      spawned(gamestats, state);
      *state = MOVING;
      break;
    case MOVING:
      moved(userAct, state, gamestats, fnow);

      break;
    case SHIFTING:
      shifted(state, fnow, gamestats);

      break;
    case ATTACHING:
      attach(state, gamestats, fnow);

      break;
    case GAMEOVER:
      hide_figure(gamestats->fnext);
      game_over();
      *state = START;
      break;
    default:
      break;
  }
}
// Локальное состояние FSM (вместо структуры tetris_state)
static fsm_state_t current_state = START;
static figura_t current_fnow = {0};
static figura_t current_fnext = {0};

// Функции для интеграции с универсальной системой
void tetris_userInput(UserAction_t action, bool hold) {
    // Игнорируем hold, так как в тетрисе он не используется
    (void)hold;
    
    // Вызываем FSM с текущим действием
    // Создаем временный GameInfo_t для передачи в sigact
    GameInfo_t temp_game = {0};
    
    // Инициализируем поле, если нужно
    if (!temp_game.field) {
        temp_game.field = (int**)malloc(FIELD_N * sizeof(int*));
        for (int i = 0; i < FIELD_N; i++) {
            temp_game.field[i] = (int*)malloc(FIELD_M * sizeof(int));
            for (int j = 0; j < FIELD_M; j++) {
                temp_game.field[i][j] = 0;
            }
        }
    }
    
    sigact(&action, &current_state, (tetrisInfo_t*)&temp_game, &current_fnow);
    
    // Освобождаем временную память
    if (temp_game.field) {
        for (int i = 0; i < FIELD_N; i++) {
            free(temp_game.field[i]);
        }
        free(temp_game.field);
    }
}

GameInfo_t tetris_updateCurrentState() {
    GameInfo_t result = {0};
    
    // Инициализируем поле
    result.field = (int**)malloc(FIELD_N * sizeof(int*));
    for (int i = 0; i < FIELD_N; i++) {
        result.field[i] = (int*)malloc(FIELD_M * sizeof(int));
        for (int j = 0; j < FIELD_M; j++) {
            result.field[i][j] = 0;
        }
    }
    
    // Заполняем базовые поля
    result.score = 0;
    result.high_score = 0;
    result.level = 1;
    result.speed = 1;
    result.pause = 0;
    
    // Здесь должна быть логика заполнения result на основе текущего состояния
    // Например, если есть активная игра, копируем данные из текущих структур
    
    return result;
}

// Функция инициализации тетриса
void initialize_tetris() {
    current_state = START;
    
    // Инициализируем фигуры
    init_figura(&current_fnow);
    init_figura(&current_fnext);
}

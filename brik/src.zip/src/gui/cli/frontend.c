#include "../../inc/Brick_frontend.h"
#include "../../inc/BrickGame.h"
#include "../../brick_game/game_router.c"
#include <stdlib.h>
#include <time.h>
#include <locale.h>


void print_rectangle(int top_y, int bottom_y, int left_x, int right_x) {
  MVADDCH(top_y, left_x, ACS_ULCORNER);

  int i = left_x + 1;
  for (; i < right_x; i++) MVADDCH(top_y, i, ACS_HLINE);
  MVADDCH(top_y, i, ACS_URCORNER);

  for (i = top_y + 1; i < bottom_y; i++) {
    MVADDCH(i, left_x, ACS_VLINE);
    MVADDCH(i, right_x, ACS_VLINE);
  }

  MVADDCH(bottom_y, left_x, ACS_LLCORNER);
  i = left_x + 1;
  for (; i < right_x; i++) MVADDCH(bottom_y, i, ACS_HLINE);
  MVADDCH(bottom_y, i, ACS_LRCORNER);
}

void print_overlay(void) {
  print_rectangle(0, BOARD_N + 1, 1, BOARD_M + 2);

  MVPRINTW(R_NEXT + 8, BOARD_M + SHIFT_MESSAGE, "LEVEL");
  MVPRINTW(R_NEXT + 10, BOARD_M + SHIFT_MESSAGE, "SCORE");
  MVPRINTW(R_NEXT + 12, BOARD_M + SHIFT_MESSAGE, "SPEED");
  MVPRINTW(R_NEXT + 14, BOARD_M + SHIFT_MESSAGE, "MAX_SCORE");

  show_intro();
}

void show_intro() {
  int start = BOARD_N / 2 - 6;
  int y = 4;
  MVPRINTW(start, y, "Press");
  MVPRINTW(start + 1, y, "ENTER - start");
  MVPRINTW(start + 5, y, "USED:");
  MVPRINTW(start + 6, y, "P - pause");
  MVPRINTW(start + 7, y, "SPACE - rotate");
  MVPRINTW(start + 8, y, "ESC - EXIT");
  MVPRINTW(start + 9, y, "RIGHT");
  MVPRINTW(start + 10, y, "LEFT");
  MVPRINTW(start + 11, y, "DOWN");
  MVPRINTW(start + 12, y, "UP - extra down");
}

void init_colors(void) {
  if (!has_colors()) {
    endwin();
    printf("COLORS NOT SUPPORTED");
  }
  start_color();
  init_pair(FIGURE_HIDE, COLOR_BLACK, COLOR_BLACK);
  init_pair(MASSEGE, COLOR_WHITE, COLOR_BLACK);
  init_pair(COLOR_1, COLOR_BLACK, COLOR_YELLOW);
  init_pair(COLOR_2, COLOR_BLACK, 190);
  init_pair(COLOR_3, COLOR_BLACK, COLOR_RED);
  init_pair(COLOR_4, COLOR_BLACK, COLOR_GREEN);
  init_pair(COLOR_5, COLOR_BLACK, 70);
  init_pair(COLOR_6, COLOR_BLACK, 60);
  init_pair(COLOR_7, COLOR_BLACK, COLOR_MAGENTA);
  init_pair(COLOR_8, COLOR_BLACK, 90);
  init_pair(COLOR_9, COLOR_BLACK, COLOR_CYAN);

  init_pair(COLOR_10, COLOR_BLACK, 100);
  init_pair(COLOR_11, COLOR_BLACK, 210);
  init_pair(COLOR_12, COLOR_BLACK, 220);
  init_pair(COLOR_13, COLOR_BLACK, 230);
  init_pair(COLOR_14, COLOR_BLACK, 240);
  init_pair(COLOR_15, COLOR_BLACK, 250);
  init_pair(COLOR_16, COLOR_BLACK, COLOR_RED);
  init_pair(COLOR_17, COLOR_BLACK, 100);
  init_pair(COLOR_18, COLOR_BLACK, 80);
  init_pair(COLOR_19, COLOR_BLACK, 200);
  init_pair(COLOR_PINK, COLOR_BLACK, 213);
}

void game_over(void) {
  MVPRINTW(BOARD_N / 2, BOARD_M / 2, "GAME");
  MVPRINTW(BOARD_N / 2 + 1, BOARD_M / 2, "OVER");
}

void print_stats(GameInfo_t *game) {
  bkgdset(COLOR_PAIR(MASSEGE));
  int start_y = R_NEXT;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "NEXT");
  start_y += 6;
  if (game->pause)
    print_pause();
  else
    MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "CAPYBARA_GAMES");
  start_y += 3;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->level);
  start_y += 2;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->score);
  start_y += 2;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->speed);
  start_y += 2;
  if (game->score > game->high_score)
    MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->score);
  else
    MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->high_score);
}

void print_figure(const figura_t *f) {
  for (int i = 1; i < f->n + 1; i++)
    for (int j = 1; j < f->m + 1; j++) {
      if (f->figura[i - 1][j - 1] == 1) PRINT((f->x * 2 + j * 2), f->y + i);
    }
}

void print_pause(void) {
  bkgdset(COLOR_PAIR(MASSEGE));
  MVPRINTW(BOARD_N / 2, BOARD_M / 2, "PAUSE");
}

void hide_figure(const figura_t *f) {
  bkgdset(COLOR_PAIR(FIGURE_HIDE));
  print_figure(f);
}

void show_figure(figura_t *f) {
  bkgdset(COLOR_PAIR(f->typeFigure));
  print_figure(f);
}

void refresh_figure(figura_t *f, int dx, int dy) {
  hide_figure(f);
  f->x += dx;
  f->y += dy;
  show_figure(f);
}

void refresh_game_field(GameInfo_t *game) {
  bkgdset(COLOR_PAIR(0));
  for (int i = 1; i < BOARD_N + 1; i++)
    for (int j = 1; j < BOARD_M + 1; j++) {
      PRINT(j, i);
    }
  print_game_field(game);
  bkgdset(COLOR_PAIR(MASSEGE));
  print_rectangle(0, BOARD_N + 1, 1, BOARD_M + 2);
}

void print_game_field(GameInfo_t *game) {
  for (int i = 1; i < FIELD_N + 1; i++)
    for (int j = 1; j < FIELD_M + 1; j++) {
      if (game->field[i - 1][j - 1]) {
        bkgdset(COLOR_PAIR(game->field[i - 1][j - 1]));
        PRINT(j * 2, i);
      }
    }
}

int select_game_type(void) {
    clear();
    MVPRINTW(5, 10, "Select game:");
    MVPRINTW(7, 10, "1 - Tetris");
    MVPRINTW(8, 10, "2 - Snake");
    MVPRINTW(10, 10, "Press 1 or 2 to select");
    refresh();

    while (1) {
        int choice = getch();
        if (choice == '1') return 0; // Tetris
        if (choice == '2') return 1; // Snake
        if (choice == ESCAPE) return -1; // Exit
    }
}

void initialize_selected_game(int game_type) {
    if (game_type == 1) {
        print_overlay();
    } else { // GAME_SNAKE
        // Специфичная инициализация для змейки
        print_rectangle(0, BOARD_N + 1, 1, BOARD_M + 2);
        MVPRINTW(5, 10, "SNAKE GAME - Press ENTER to start");
        MVPRINTW(7, 10, "Use arrows to control");
        MVPRINTW(8, 10, "P - Pause, ESC - Exit");
    }
}

void run_game_loop(int game_type) {
    bool game_running = TRUE;
    
    while (game_running) {
        // Обработка ввода
        int input = GET_USER_INPUT;
        UserAction_t action = get_signal(input);

        // Выход из игры
        if (action == Terminate) {
            game_running = FALSE;
            continue;
        }

        // Передача действия в игровую логику
        userInput(action, FALSE);

        // Обновление игрового состояния
        GameInfo_t current_state = updateCurrentState();

        // Проверка условий завершения через состояние паузы
        if (current_state.pause == GAME_EXIT) {
            game_running = FALSE;
        }

        // Отрисовка игрового поля
        refresh_game_field(&current_state);
        
        // Отображение статистики (адаптируется под игру автоматически)
        print_stats(&current_state);

        // Для змейки используем свою скорость, для тетриса - свою
        int game_speed = (game_type == 2) ? 
                        (current_state.speed > 0 ? current_state.speed : 100) : 
                        current_state.speed;
        timeout(game_speed);
    }
}

int main(void) {
    // Инициализация ncurses
    WIN_INIT(250);
    setlocale(LC_ALL, "");
    init_colors();
    srand(time(NULL));

    // Выбор типа игры
    int game_type = select_game_type();
    if (game_type == -1) {
        endwin();
        return SUCCESS;
    }

    // Инициализация выбранной игры
    initialize_selected_game(game_type);

    // Запуск основного игрового цикла
    run_game_loop(game_type);

    // Завершение работы
    endwin();
    return SUCCESS;
}

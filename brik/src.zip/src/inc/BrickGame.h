#ifndef BRICKGAME_H
#define BRICKGAME_H

// Добавляем структуру для универсального состояния игры
typedef struct {
    int game_type; // GAME_TETRIS или GAME_SNAKE
    void* game_data; // Указатель на специфичные данные игры
} GameConfig_t;

typedef enum {
    Start,
    Pause,
    Terminate,
    Left,
    Right,
    Up,
    Down,
    Action
} UserAction_t;

typedef struct {
    int **field;
    int **next;
    int score;
    int high_score;
    int level;
    int speed;
    int pause;
} GameInfo_t;

typedef enum {
  START = 0,
  SPAWN,
  MOVING,
  SHIFTING,
  ATTACHING,
  GAMEOVER,
  EXIT
} fsm_state_t;

void userInput(UserAction_t action, bool hold);

GameInfo_t updateCurrentState();
// Добавляем функцию для инициализации конкретной игры
void initializeGame(GameType_t game_type);

#endif

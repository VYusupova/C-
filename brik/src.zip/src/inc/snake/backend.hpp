#include <cmath>
#include <new>
#include <stdexcept>
#include <vector>
#include <utility>
#include "../BrickGame.h"
#include "../defines.h"

namespace s21 {
class snake {
	public:
	  Snake();
	  ~Snake();
	  void move();
	  bool checkCollision() const;
	  void changeDirection(int newDir);
	  Snake(const Snake&) = delete;
	  Snake& operator=(const Snake&) = delete;

		const std::pair<int, int>& getHead() const { return body.front(); }
    const std::pair<int, int>& getTail() const { return body.back(); }
    const std::vector<std::pair<int, int>>& getBody() const { return body; }
    size_t getLength() const { return body.size(); }
	private:
	  void FreeGameMemory();
		std::vector<std::pair<int, int>> body;  // Сегменты змейки (x, y)
	  int direction;  // 0: вверх, 1: вправо, 2: вниз, 3: влево
		const int max_snake_length = 200;
		void snake_init();
	  void SpawnFruit();
	  void FruitEat(int fruit_x, int fruit_y);
		GameInfo_t game;
		GameInfo_t copy;
		bool needsToGrow = false;
}
}

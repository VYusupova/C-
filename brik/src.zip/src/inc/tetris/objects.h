#ifndef OBJECTS_H
#define OBJECTS_H

#include <ncurses.h>

#include "../defines.h"
#include "../BrickGame.h"

// Добавляем псевдоним для совместимости
//typedef GameInfo_t tetrisInfo_t; // Для обратной совместимости с существующим кодом

typedef struct {
  int n;
  int m;
  int x;
  int y;
  int figura[FSIZE][FSIZE];
  int typeFigure;
} figura_t;  // параметры фигуры

typedef struct {
  char finish[BOARD_M + 2];
  char ways[ROWS_MAP + 2][COLS_MAP + 2];
} board_t;

typedef enum {
  FIGURE_Q = 1,
  FIGURE_I,
  FIGURE_S,
  FIGURE_Z,
  FIGURE_L,
  FIGURE_J,
  FIGURE_T
} list_figures_t;

#endif

#ifndef TETRIS_BACKEND_H
#define TETRIS_BACKEND_H

#include <ncurses.h>
#include <stdlib.h>
#include <string.h>

#include "fsm.h"
#include "../defines.h"
#include "objects.h"

// инициализация фигур
void init_figura(figura_t *f);
void init_figura_Q(figura_t *f);
void init_figura_I(figura_t *f);
void init_figura_S(figura_t *f);
void init_figura_Z(figura_t *f);
void init_figura_L(figura_t *f);
void init_figura_J(figura_t *f);
void init_figura_T(figura_t *f);

void init_game(tetrisInfo_t *state);
// фиксирование фигуры на игровом поле
void figura_game_field(tetrisInfo_t *game);
// инициализация стартовой точки фигуры
void init_start_position(figura_t *f, int x, int y);
// замена на новую фигуру
void spawn_new_figure(figura_t *fnow, figura_t *fnext);
// проверка столкновений
int check_collision_field(tetrisInfo_t *state, int down, int left);
int collision_left(const figura_t *f, tetrisInfo_t *state);
int collision_right(const figura_t *f, tetrisInfo_t *state);
int collision_up(const figura_t *f/*, tetrisInfo_t *state*/);
int collision_down(const figura_t *f, tetrisInfo_t *state);
// перемещение
void rotate_figure(figura_t *f, tetrisInfo_t *state);

#endif

#ifndef FSM_H
#define FSM_H

#include "../defines.h"
#include "objects.h"
#include "BrickGame.h"

typedef struct GameInfo_t {
  int field[FIELD_N][FIELD_M];
  int score;
  int high_score;
  int level;
  int speed;
  int pause;
  figura_t *fnext;
  figura_t *fnow;
} tetrisInfo_t;

UserAction_t get_signal(int user_input);
void sigact(const UserAction_t *sig, fsm_state_t *state, tetrisInfo_t *stats,
            figura_t *fnow);

void initialize_tetris();
GameInfo_t tetris_updateCurrentState();
void tetris_userInput(UserAction_t action, bool hold);

#endif

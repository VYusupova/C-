#ifndef INC_TETRIS_H
#define INC_TETRIS_H

#include <locale.h>

#include "fsm.h"
#include "objects.h"
#include "tetris_backend.h"
#include "../Brick_frontend.h"

void game_loop();
// подсчет очков
void score(GameInfo_t *game);
void level_up(GameInfo_t *game);
void shift_field(GameInfo_t *game, int y);
void write_score(const GameInfo_t *game);
int read_score();
// Функции для преобразования между tetrisInfo_t и GameInfo_t
void tetrisInfo_to_GameInfo(const tetrisInfo_t* src, GameInfo_t* dest);
void GameInfo_to_tetrisInfo(const GameInfo_t* src, tetrisInfo_t* dest);
void init_tetris_game_adapter(tetrisInfo_t* game, figura_t* fnow, figura_t* fnext);

#endif

#include "../../inc/frontend.h"

void print_rectangle(int top_y, int bottom_y, int left_x, int right_x) {
  MVADDCH(top_y, left_x, ACS_ULCORNER);

  int i = left_x + 1;
  for (; i < right_x; i++) MVADDCH(top_y, i, ACS_HLINE);
  MVADDCH(top_y, i, ACS_URCORNER);

  for (i = top_y + 1; i < bottom_y; i++) {
    MVADDCH(i, left_x, ACS_VLINE);
    MVADDCH(i, right_x, ACS_VLINE);
  }

  MVADDCH(bottom_y, left_x, ACS_LLCORNER);
  i = left_x + 1;
  for (; i < right_x; i++) MVADDCH(bottom_y, i, ACS_HLINE);
  MVADDCH(bottom_y, i, ACS_LRCORNER);
}

void print_overlay(void) {
  print_rectangle(0, BOARD_N + 1, 1, BOARD_M + 2);

  MVPRINTW(R_NEXT + 8, BOARD_M + SHIFT_MESSAGE, "LEVEL");
  MVPRINTW(R_NEXT + 10, BOARD_M + SHIFT_MESSAGE, "SCORE");
  MVPRINTW(R_NEXT + 12, BOARD_M + SHIFT_MESSAGE, "SPEED");
  MVPRINTW(R_NEXT + 14, BOARD_M + SHIFT_MESSAGE, "MAX_SCORE");

  show_intro();
}

void show_intro() {
  int start = BOARD_N / 2 - 6;
  int y = 4;
  MVPRINTW(start, y, "Press");
  MVPRINTW(start + 1, y, "ENTER - start");
  MVPRINTW(start + 5, y, "USED:");
  MVPRINTW(start + 6, y, "P - pause");
  MVPRINTW(start + 7, y, "SPACE - rotate");
  MVPRINTW(start + 8, y, "ESC - EXIT");
  MVPRINTW(start + 9, y, "RIGHT");
  MVPRINTW(start + 10, y, "LEFT");
  MVPRINTW(start + 11, y, "DOWN");
  MVPRINTW(start + 12, y, "UP - extra down");
}

void init_colors(void) {
  if (!has_colors()) {
    endwin();
    printf("COLORS NOT SUPPORTED");
  }
  start_color();
  init_pair(FIGURE_HIDE, COLOR_BLACK, COLOR_BLACK);
  init_pair(MASSEGE, COLOR_WHITE, COLOR_BLACK);
  init_pair(COLOR_1, COLOR_BLACK, COLOR_YELLOW);
  init_pair(COLOR_2, COLOR_BLACK, 190);
  init_pair(COLOR_3, COLOR_BLACK, COLOR_RED);
  init_pair(COLOR_4, COLOR_BLACK, COLOR_GREEN);
  init_pair(COLOR_5, COLOR_BLACK, 70);
  init_pair(COLOR_6, COLOR_BLACK, 60);
  init_pair(COLOR_7, COLOR_BLACK, COLOR_MAGENTA);
  init_pair(COLOR_8, COLOR_BLACK, 90);
  init_pair(COLOR_9, COLOR_BLACK, COLOR_CYAN);

  init_pair(COLOR_10, COLOR_BLACK, 100);
  init_pair(COLOR_11, COLOR_BLACK, 210);
  init_pair(COLOR_12, COLOR_BLACK, 220);
  init_pair(COLOR_13, COLOR_BLACK, 230);
  init_pair(COLOR_14, COLOR_BLACK, 240);
  init_pair(COLOR_15, COLOR_BLACK, 250);
  init_pair(COLOR_16, COLOR_BLACK, COLOR_RED);
  init_pair(COLOR_17, COLOR_BLACK, 100);
  init_pair(COLOR_18, COLOR_BLACK, 80);
  init_pair(COLOR_19, COLOR_BLACK, 200);
  init_pair(COLOR_PINK, COLOR_BLACK, 213);
}

void game_over(void) {
  MVPRINTW(BOARD_N / 2, BOARD_M / 2, "GAME");
  MVPRINTW(BOARD_N / 2 + 1, BOARD_M / 2, "OVER");
}

void print_stats(GameInfo_t *game) {
  bkgdset(COLOR_PAIR(MASSEGE));
  int start_y = R_NEXT;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "NEXT");
  start_y += 6;
  if (game->pause)
    print_pause();
  else
    MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "CAPYBARA_GAMES");
  start_y += 3;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->level);
  start_y += 2;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->score);
  start_y += 2;
  MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->speed);
  start_y += 2;
  if (game->score > game->high_score)
    MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->score);
  else
    MVPRINTW(start_y, BOARD_M + SHIFT_MESSAGE, "%d", game->high_score);
}

void print_figure(const figura_t *f) {
  for (int i = 1; i < f->n + 1; i++)
    for (int j = 1; j < f->m + 1; j++) {
      if (f->figura[i - 1][j - 1] == 1) PRINT((f->x * 2 + j * 2), f->y + i);
    }
}

void print_pause(void) {
  bkgdset(COLOR_PAIR(MASSEGE));
  MVPRINTW(BOARD_N / 2, BOARD_M / 2, "PAUSE");
}

void hide_figure(const figura_t *f) {
  bkgdset(COLOR_PAIR(FIGURE_HIDE));
  print_figure(f);
}

void show_figure(figura_t *f) {
  bkgdset(COLOR_PAIR(f->typeFigure));
  print_figure(f);
}

void refresh_figure(figura_t *f, int dx, int dy) {
  hide_figure(f);
  f->x += dx;
  f->y += dy;
  show_figure(f);
}

void refresh_game_field(GameInfo_t *game) {
    bkgdset(COLOR_PAIR(0));
    for (int i = 1; i < BOARD_N + 1; i++) {
        for (int j = 1; j < BOARD_M + 1; j++) {
            PRINT(j, i);
        }
    }
    print_game_field(game);
    bkgdset(COLOR_PAIR(MASSEGE));
    print_rectangle(0, BOARD_N + 1, 1, BOARD_M + 2);
}

void print_game_field(GameInfo_t *game) {
  for (int i = 1; i < FIELD_N + 1; i++)
    for (int j = 1; j < FIELD_M + 1; j++) {
      if (game->field[i - 1][j - 1]) {
        bkgdset(COLOR_PAIR(game->field[i - 1][j - 1]));
        PRINT(j * 2, i);
      }
    }
}

void print_menu() {
  print_rectangle(0, BOARD_N + 1, 1, BOARD_M + 2);
  MVPRINTW(4, 6, "BrickGame");
  MVPRINTW(BOARD_N / 2 + 1, 6, "tetris - t");
  MVPRINTW(BOARD_N / 2 + 2, 6, "snake - s");
  MVPRINTW(BOARD_N / 2 + 3, 6, "exit - ESC");
}

// #ifdef __cplusplus
// extern "C" {
// #endif



// }

// #ifdef __cplusplus
// }
// #endif

void print_snake_field(GameInfo_t *game) {
    for (int i = 1; i < FIELD_N + 1; i++) {
        for (int j = 1; j < FIELD_M + 1; j++) {
            if (game->field[i - 1][j - 1]) {
                // Голова змейки - красный, тело - зеленый, фрукт - желтый
                int color;
                if (game->field[i - 1][j - 1] == 1) {
                    color = COLOR_3; // красный для головы
                } else if (game->field[i - 1][j - 1] == 2) {
                    color = COLOR_4; // зеленый для тела
                } else if (game->field[i - 1][j - 1] == 3) {
                    color = COLOR_1; // желтый для фрукта
                } else {
                    color = 0;
                }
                bkgdset(COLOR_PAIR(color));
                PRINT(j * 2, i);
            }
        }
    }
}


UserAction_t get_signal(int user_input) {
  UserAction_t action;

  switch (user_input) {
    case 72:
      action = Up;
      break;
    case 40:
      action = Down;
      break;
    case 75:
      action = Left;
      break;
    case 77:
      action = Right;
      break;
    case ESCAPE:
      action = Terminate;
      break;
    case ENTER_KEY:
      action = Start;
      break;
    case SPACE:
      action = Action;
      break;
    case PAUSE_p:
      action = Pause;
      break;
    case PAUSE_P:
      action = Pause;
      break;
    default:
      break;
  }
  return action;
}

void snake_game_loop(void) {
    bool break_flag = true;
    int frames = 0;

    print_overlay();
    //MVPRINTW(0, BOARD_M + SHIFT_MESSAGE + 15, "SNAKE");
    //MVPRINTW(1, BOARD_M + SHIFT_MESSAGE + 15, "ESC to exit");

    while (break_flag) {
        // Получить пользовательский ввод
        int input = GET_USER_INPUT;
        UserAction_t action = get_signal(input);

        // Обработать ввод
        s21::fsm::snake_userInput(action, false);

        // Обновить состояние
        GameInfo_t current_state = s21::fsm::snake_updateCurrentState();

        // Отрисовать
        refresh_game_field(&current_state);
        print_stats(&current_state);

        // Обновить экран
        refresh();

        // Задержка для контроля скорости
        timeout(100 - (current_state.speed * 8)); // скорость зависит от счета

        // Проверить выход
        if (action == Terminate) {
            break_flag = false;
        }

        frames++;
        napms(50); // 20 FPS
    }
}

int main(void) {
  WIN_INIT(250);
  setlocale(LC_ALL, "");
  srand(time(NULL));
  init_colors();
  bool break_flag = true;
  while(break_flag) {
    print_menu();
    char imput = GET_USER_INPUT;
    if(imput == BUTTON_T || imput == BUTTON_t) {
      print_overlay();
      UserAction_t action = get_signal(GET_USER_INPUT);
      s21::fsm::snake_userInput(action, false);
      clear();
    }
    if(imput == BUTTON_S || imput == BUTTON_s) {
      snake_game_loop();
      clear();
    }
    if(imput == ESCAPE) break_flag = false;
  }

  endwin();

  return SUCCESS;
}

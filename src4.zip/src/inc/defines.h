#ifndef DEFINES_H
#define DEFINES_H
// инициализация ncurses
#define WIN_INIT(time)    \
  {                       \
    initscr();            \
    noecho();             \
    curs_set(0);          \
    keypad(stdscr, TRUE); \
    timeout(time);        \
  }
// ввод пользователя
#define GET_USER_INPUT getch()
// игровое поле и фигуры
#define PRINT(x, y) mvprintw(BOARDS_BEGIN + (y), BOARDS_BEGIN + (x), "  ")
#define MVPRINTW(y, x, ...) \
  mvprintw(BOARDS_BEGIN + (y), BOARDS_BEGIN + (x), __VA_ARGS__)
#define MVADDCH(y, x, c) mvaddch(BOARDS_BEGIN + (y), BOARDS_BEGIN + (x), c)

#define INTRO_MESSAGE "Press ENTER to start!"
#define INTRO_MESSAGE_LEN 21

#define ROWS_MAP 21
#define COLS_MAP 90

#define FSIZE 4

#define BOARDS_BEGIN 0
// стартовые позиции фигуры
#define START_X (FIELD_M / 2) - 1
#define START_Y MAP_PADDING
#define MAP_PADDING 0

#define R_NEXT 1
#define R_NEXT_H 7
#define R_NEXT_X FIELD_M + 2
#define R_NEXT_Y 2

#define INITIAL_TIMEOUT 150

#define BOARD_N 20
#define BOARD_M FIELD_M * 2
#define FIELD_N 20
#define FIELD_M 10
#define HUD_WIDTH 10

#define MAX_SCORE "tetris_max_score.txt"

#define MAX_LEVEL 10
#define SPEED 780

#define INIRIAL_RIMEOUT 150

#define SUCCESS 0
#define ERROR 1

#define ESCAPE 27
#define ENTER_KEY 10
#define PAUSE_P 80
#define PAUSE_p 112
#define SPACE ' '

#define BUTTON_S 83
#define BUTTON_s 115
#define BUTTON_T 84
#define BUTTON_t 116

#define SHIFT_MESSAGE 4

#endif

#ifndef FSM_H
#define FSM_H

#include "../defines.h"
#include "../frontend.h"
#include "objects.h"
#include "tetris.h"
#include "tetris_backend.h"

UserAction_t get_signal(int user_input);
void sigact(const UserAction_t *sig, fsm_state_t *state, GameInfo_t *stats,
            figura_t *fnow, figura_t *fnext);

#endif

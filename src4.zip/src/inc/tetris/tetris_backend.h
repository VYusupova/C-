#ifndef TETRIS_BACKEND_H
#define TETRIS_BACKEND_H

#include <ncurses.h>
#include <stdlib.h>

#include "../BrickGame.h"
#include "../defines.h"
#include "fsm.h"
#include "objects.h"

// инициализация фигур
void init_figura(figura_t *f);
void init_figura_Q(figura_t *f);
void init_figura_I(figura_t *f);
void init_figura_S(figura_t *f);
void init_figura_Z(figura_t *f);
void init_figura_L(figura_t *f);
void init_figura_J(figura_t *f);
void init_figura_T(figura_t *f);

void init_game(GameInfo_t *state, figura_t *fnow, figura_t *fnext);
void tetris_field_free(GameInfo_t *state);
// фиксирование фигуры на игровом поле
void figura_game_field(GameInfo_t *game, const figura_t *fnow);
// инициализация стартовой точки фигуры
void init_start_position(figura_t *f, int x, int y);
// замена на новую фигуру
void spawn_new_figure(figura_t *fnow, figura_t *fnext);
// проверка столкновений
int check_collision_field(const GameInfo_t *state, int down, int left,
                          const figura_t *fnow);
int collision_left(const figura_t *f, const GameInfo_t *state);
int collision_right(const figura_t *f, const GameInfo_t *state);
int collision_up(const figura_t *f);
int collision_down(const figura_t *f, const GameInfo_t *state);
// перемещение
void rotate_figure(figura_t *f, const GameInfo_t *state);

#endif

#ifndef INC_TETRIS_H
#define INC_TETRIS_H

#include <locale.h>

#include "../BrickGame.h"
#include "fsm.h"
#include "objects.h"

// подсчет очков
void score(GameInfo_t *game);
void level_up(GameInfo_t *game);
void shift_field(GameInfo_t *game, int y);
void write_score(const GameInfo_t *game);
int read_score();

#endif

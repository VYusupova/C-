#ifndef TETRIS_FRONTEND_H
#define TETRIS_FRONTEND_H

#include "tetris/tetris.h"
#include "tetris/objects.h"
#include "snake/backend.hpp"
#include "snake/fsm.hpp"
#include "defines.h"

#include <time.h>

typedef enum {
  FIGURE_HIDE = 0,
  COLOR_1 = 1,
  COLOR_2,
  COLOR_3,
  COLOR_4,
  COLOR_5,
  COLOR_6,
  COLOR_7,
  COLOR_8,
  COLOR_9,
  COLOR_10,
  COLOR_11,
  COLOR_12,
  COLOR_13,
  COLOR_14,
  COLOR_15,
  COLOR_16,
  COLOR_17,
  COLOR_18,
  COLOR_19,
  COLOR_PINK,
  MASSEGE = 50
} colors_t;

UserAction_t get_signal(int user_input);

void init_colors(void);
void game_over(void);
void print_stats(GameInfo_t *game);
void print_overlay(void);
void print_pause(void);
void hide_figure(const figura_t *f);
void show_figure(figura_t *f);
void refresh_figure(figura_t *f, int dx, int dy);
void refresh_game_field(GameInfo_t *game);
void print_rectangle(int top_y, int bottom_y, int left_x, int right_x);
void show_intro();
void print_game_field(GameInfo_t *game);
void print_figure(const figura_t *f);
void game_loop();

#endif

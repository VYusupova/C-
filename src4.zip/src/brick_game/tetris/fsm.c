#include "../../inc/tetris/fsm.h"

#include <string.h>

// This is a finite state machine realisation based on switch-case statement.
/*

    States are checked in order specified in function sigact().
    It enters a state-case which it corresponds to, where begins another
switch-case statement. Inner switch-case statement is looking for a signal given
by get_signal(). After finding it makes some action and switches state to the
next one.

    Pros:
        1) Less memory usage.
    Cons:
        1) A lot of codelines.
*/

UserAction_t get_signal(int user_input) {
  UserAction_t action;

  switch (user_input) {
    case KEY_UP:
      action = Up;
      break;
    case KEY_DOWN:
      action = Down;
      break;
    case KEY_LEFT:
      action = Left;
      break;
    case KEY_RIGHT:
      action = Right;
      break;
    case ESCAPE:
      action = Terminate;
      break;
    case ENTER_KEY:
      action = Start;
      break;
    case SPACE:
      action = Action;
      break;
    case PAUSE_p:
    case PAUSE_P:
      action = Pause;
      break;
    default:
      break;
  }
  return action;
}

void shifted(fsm_state_t *state, figura_t *f, const GameInfo_t *game) {
  if (!collision_down(f, game)) {
    refresh_figure(f, 0, 1);
    *state = MOVING;
  } else {
    *state = ATTACHING;
  }
}

void rotate(figura_t *f, const GameInfo_t *gb) {
  hide_figure(f);
  rotate_figure(f, gb);
  show_figure(f);
}

void started(const UserAction_t *userAct, GameInfo_t *game, fsm_state_t *state,
             figura_t *fnow, figura_t *fnext) {
  switch (*userAct) {
    case Start:
      refresh_game_field(game);
      init_figura(fnow);
      init_figura(fnext);
      *state = SPAWN;
      break;
    case Terminate:
      *state = EXIT;
      break;
    default:
      break;
  }
}

void spawned(figura_t *fnow, figura_t *fnext) {
  spawn_new_figure(fnow, fnext);
  hide_figure(fnext);
  init_figura(fnext);
  show_figure(fnext);
  show_figure(fnow);
}

void attach(fsm_state_t *state, GameInfo_t *game, const figura_t *f) {
  if (collision_up(f)) {
    *state = GAMEOVER;
  } else
    *state = SPAWN;
  figura_game_field(game, f);
  score(game);
  refresh_game_field(game);
}

void moved(const UserAction_t *userAct, fsm_state_t *state, GameInfo_t *game,
           figura_t *fnow) {
  switch (*userAct) {
    case Up:
      while (*state != ATTACHING) {
        shifted(state, fnow, game);
      }
      break;
    case Left:
      if (!collision_left(fnow, game)) refresh_figure(fnow, -1, 0);
      *state = SHIFTING;
      break;
    case Right:
      if (!collision_right(fnow, game)) refresh_figure(fnow, 1, 0);
      *state = SHIFTING;
      break;
    case Down:
      shifted(state, fnow, game);
      shifted(state, fnow, game);
      break;
    case Action:
      rotate(fnow, game);
      *state = SHIFTING;
      break;
    case Pause:
      *state = SHIFTING;
      game->pause = 1;
      print_stats(game);
      while (game->pause) {
        UserAction_t action = get_signal(GET_USER_INPUT);
        if (action == Pause) game->pause = 0;
        if (action == Start) game->pause = 0;
        if (action == Terminate) {
          game->pause = 0;
          *state = EXIT;
        }
      }
      print_stats(game);
      refresh_game_field(game);
      refresh_figure(fnow, 0, 0);
      break;
    case Terminate:
      *state = EXIT;
      break;
    default:
      *state = SHIFTING;
      break;
  }
}

void sigact(const UserAction_t *userAct, fsm_state_t *state,
            GameInfo_t *gamestats, figura_t *fnow, figura_t *fnext) {
  switch (*state) {
    case START:
      init_game(gamestats, fnow, fnext);
      started(userAct, gamestats, state, fnow, fnext);
      break;
    case SPAWN:
      spawned(fnow, fnext);
      *state = MOVING;
      break;
    case MOVING:
      moved(userAct, state, gamestats, fnow);

      break;
    case SHIFTING:
      shifted(state, fnow, gamestats);

      break;
    case ATTACHING:
      attach(state, gamestats, fnow);

      break;
    case GAMEOVER:
      hide_figure(fnext);
      game_over();
      *state = START;
      break;
    default:
      break;
  }
  print_stats(gamestats);
}

void userInput(UserAction_t action, bool hold __attribute__((unused))) {
  GameInfo_t game;
  figura_t fnow;
  figura_t fnext;
  bool break_flag = TRUE;

  fsm_state_t state = START;
  memset(&game, 0, sizeof(GameInfo_t));

  while (break_flag) {
    if (state == EXIT) break_flag = FALSE;

    sigact(&action, &state, &game, &fnow, &fnext);
    if (state == MOVING || state == START) action = get_signal(GET_USER_INPUT);
    timeout(game.speed);
    write_score(&game);
  }
  tetris_field_free(&game);
}

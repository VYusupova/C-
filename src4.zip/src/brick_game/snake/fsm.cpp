#include "../../inc/snake/fsm.hpp"


namespace s21 {

static s21::snake snake_instance;


void fsm::sigact(const UserAction_t *userAct, GameInfo_t *gamestats, fsm_state_t *state) {
    switch (*state) {
        case START:
            if (*userAct == Start) {
                started(gamestats);
                *state = MOVING;
            }
            break;
        case MOVING:
            moved(userAct, gamestats);
            break;
        case GAMEOVER:
            if (*userAct == Start) {
                started(gamestats);
                *state = MOVING;
            }
            //GameOver();
            break;
        default:
            break;
    }
}

void fsm::started(GameInfo_t *game) {
    // Реинициализация игры
    snake_instance.resetGame();  // нужен экземпляр snake
    game->score = 0;
    game->level = 1;
    game->speed = 1;
    game->pause = 0;
}

void fsm::moved(const UserAction_t *userAct, GameInfo_t *game) {
    switch (*userAct) {
        case Up:
            snake_instance.changeDirection(0);
            break;
        case Right:
            snake_instance.changeDirection(1);
            break;
        case Down:
            snake_instance.changeDirection(2);
            break;
        case Left:
            snake_instance.changeDirection(3);
            break;
        case Pause:
            game->pause = !game->pause;
            break;
        default:
            break;
    }

    if (!game->pause) {
      snake_instance.move();
        *game = snake_instance.getGameState();  // обновить состояние игры
    }
}


void fsm::snake_userInput(UserAction_t action, bool hold) {
  hold = 0;
  if (hold) hold = 1;
  // if (NULL == snake_instance) {
  //   snake_instance.snake();
  // }

  switch (action) {
    case Start:
      snake_instance.resetGame();
      break;
    case Pause:
      snake_instance.setPause(!snake_instance.getGameState().pause);
      break;
    case Up:
      snake_instance.changeDirection(0);
      break;
    case Right:
      snake_instance.changeDirection(1);
      break;
    case Down:
      snake_instance.changeDirection(2);
      break;
    case Left:
      snake_instance.changeDirection(3);
      break;
    case Terminate:
      // if (snake_instance) {
      //   delete snake_instance;
      //   snake_instance = NULL;
      // }
      break;
    default:
      break;
  }
}

GameInfo_t fsm::snake_updateCurrentState() {
  // if (!snake_instance) {
  //   snake_instance = new s21::snake();
  // }

  return snake_instance.getGameState();
}

void fsm::snake_cleanup(void) {
  // if (snake_instance) {
  //   delete snake_instance;
  //   snake_instance = NULL;
  // }

}

}

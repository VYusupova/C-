

#include <iostream>
#include <vector>
#include "../inc/BrickGame.h"
#include "../../inc/snake/backend.hpp"
#include <algorithm>
#include <random>

namespace s21 {

snake::snake() {
    game.field = new int*[FIELD_N];
    for (int i = 0; i < FIELD_N; ++i) {
      game.field[i] = new int[FIELD_M]{0};
    }
    copy.field = new int*[FIELD_N];
    for (int i = 0; i < FIELD_N; ++i) {
      copy.field[i] = new int[FIELD_M]{0};
    }
    game.next = NULL;
    game.pause = 0;
    game.score = 0;
    game.speed = 1;
    game.high_score = 0;
    copy.next = NULL;

    snake_init();
    SpawnFruit();
}

void snake::FreeGameMemory(GameInfo_t* game) {
	if(!game || !game->field) {
		return;
	}

	for(int i = 0; i < FIELD_N; i++) {
		delete[] game->field[i];
	}
	delete[] game->field;
	game->field = nullptr;
}

snake::~snake() {
	FreeGameMemory(&game);
        //FreeGameMemory(&copy);
}

void snake::snake_init() {
  body.clear();
	int head_x = FIELD_M / 2;
	int head_y = FIELD_N / 2;
	body.emplace_back(head_x, head_y);  // Голова
  for (int i = 0; i < 4; ++i) {
    body.emplace_back(head_x - i, head_y);
  }
  direction = 1;
}

void snake::move() {
  if (!game.pause) {
	  auto newHead = body.front();
	  switch(direction) {
	  	case 0:
	  		newHead.second--;
	  	  break;
	  	case 1:
	  		newHead.first++;
	  	  break;
	  	case 2:
	  		newHead.second++;
	  	  break;
	  	case 3:
	  		newHead.first--;
	  	  break;
	  }

    if (newHead.first < 0 || newHead.first >= FIELD_M || newHead.second < 0 || newHead.second >= FIELD_N) {
      //gameover
      return;
    }

     if (std::find(body.begin(), body.end(), newHead) != body.end()) {
        // Game Over логика
        return;
    }

	  body.insert(body.begin(), newHead);

     // Проверить съедание фрукта
    if (game.field[newHead.second][newHead.first] == 3) FruitEat();

	  if(!needsToGrow) {
	  	body.pop_back();
	  } else {
	  	needsToGrow = false;
	  }
  }
}

bool snake::checkCollision() const {
	const auto head = body.front();
	return std::any_of(body.begin() + 1, body.end(), [&head](const auto &segment){ //умнейшая разработка алгоритмов
		return head == segment;
	});
	return head.first < 0 || head.first >= FIELD_N || head.second < 0 || head.second >= FIELD_M;
}

void snake::changeDirection(int newDir) {
	if(abs(newDir - direction) != 2) {
		direction = newDir;
	}
}

void snake::SpawnFruit() {
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> x_dist(0, FIELD_N - 1);
  std::uniform_int_distribution<int> y_dist(0, FIELD_M - 1);

  int fruit_x, fruit_y;
  do {
    fruit_x = x_dist(gen);
    fruit_y = y_dist(gen);
  } while (game.field[fruit_y][fruit_x] != 0);

  game.field[fruit_y][fruit_x] = 3;
}

void snake::FruitEat() {
	game.score += 1;
	needsToGrow = true;
	if(game.speed != 10) {
	game.speed = 1 + game.score / 5;
	}
	SpawnFruit();
}

void snake::updateGameField() {
    for (int i = 0; i < FIELD_N; ++i) {
        for (int j = 0; j < FIELD_M; ++j) {
            game.field[i][j] = 0;
        }
    }
    
    for (size_t i = 0; i < body.size(); ++i) {
        int x = body[i].first;
        int y = body[i].second;
        if (x >= 0 && x < FIELD_M && y >= 0 && y < FIELD_N) {
            game.field[y][x] = (i == 0) ? 1 : 2;  // голова = 1, тело = 2
        }
    }
}

void snake::resetGame() {
    FreeGameMemory(&game);
    FreeGameMemory(&copy);
    // Переинициализация
    snake();
}

}

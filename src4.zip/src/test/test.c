#include <check.h>
#include <stdlib.h>

#include "../inc/tetris_backend.h"

#define TEST_SCORE_FILE "test_score.txt"

// Фикстура для тестов
typedef struct {
  GameInfo_t game_state;
  figura_t figure;
} TestFixture;

START_TEST(test_init_game) {
  GameInfo_t state;
  figura_t fnow, fnext;
  state.fnow = &fnow;
  state.fnext = &fnext;

  init_game(&state);

  ck_assert_int_eq(state.level, 0);
  ck_assert_int_eq(state.score, 0);
  ck_assert_int_eq(state.pause, 0);

  for (int i = 0; i < FIELD_N; i++) {
    for (int j = 0; j < FIELD_M; j++) {
      ck_assert_int_eq(state.field[i][j], 0);
    }
  }
}
END_TEST

static TestFixture* setup() {
  TestFixture* fixture = malloc(sizeof(TestFixture));

  // Инициализация игрового состояния
  fixture->game_state.level = 0;
  fixture->game_state.score = 0;
  fixture->game_state.high_score = 0;
  fixture->game_state.speed = 1.0;

  // Инициализация игрового поля
  for (int i = 0; i < FIELD_N; i++) {
    for (int j = 0; j < FIELD_M; j++) {
      fixture->game_state.field[i][j] = 0;
    }
  }

  return fixture;
}

static void teardown(TestFixture* fixture) {
  free(fixture);
  remove(TEST_SCORE_FILE);  // Удаляем тестовый файл
}

// Тест для функции score
START_TEST(test_score_calculation) {
  TestFixture* fixture = setup();

  // Создаем полностью заполненную строку
  for (int x = 0; x < FIELD_M; x++) {
    fixture->game_state.field[FIELD_N - 1][x] = 1;
  }

  score(&fixture->game_state);
  ck_assert_int_eq(fixture->game_state.score, 100);

  // Создаем две заполненные строки
  for (int x = 0; x < FIELD_M; x++) {
    fixture->game_state.field[FIELD_N - 1][x] = 1;
    fixture->game_state.field[FIELD_N - 2][x] = 1;
  }

  score(&fixture->game_state);
  ck_assert_int_eq(fixture->game_state.score, 100 + 300);

  teardown(fixture);
}
END_TEST

// Тест для функции level_up
START_TEST(test_level_up) {
  TestFixture* fixture = setup();

  fixture->game_state.score = 600;
  level_up(&fixture->game_state);
  ck_assert_int_eq(fixture->game_state.level, 1);

  fixture->game_state.score = 1200;
  level_up(&fixture->game_state);
  ck_assert_int_eq(fixture->game_state.level, 2);

  teardown(fixture);
}
END_TEST

// Тест для функции shift_field
START_TEST(test_shift_field) {
  TestFixture* fixture = setup();

  // Заполняем строку
  for (int x = 0; x < FIELD_M; x++) {
    fixture->game_state.field[5][x] = 1;
  }

  shift_field(&fixture->game_state, 5);

  teardown(fixture);
}
END_TEST

// Тест для функций записи и чтения рекорда
START_TEST(test_write_read_score) {
  GameInfo_t game;
  game.high_score = 0;
  game.score = 1000;

// Переопределяем путь к файлу для тестов
#undef MAX_SCORE
#define MAX_SCORE TEST_SCORE_FILE

  write_score(&game);
  int read = read_score();
  ck_assert_int_eq(read, 1000);

  remove(TEST_SCORE_FILE);
}
END_TEST

// Тесты для init_figura
START_TEST(test_init_figura) {
  figura_t f;
  init_figura(&f);

  // Проверяем, что фигура инициализирована
  ck_assert_int_ge(f.typeFigure, 1);
  ck_assert_int_le(f.typeFigure, COLOR_PINK);

  // Проверяем, что матрица не пустая
  int has_blocks = 0;
  for (int i = 0; i < FSIZE; i++) {
    for (int j = 0; j < FSIZE; j++) {
      if (f.figura[i][j]) has_blocks = 1;
    }
  }
  ck_assert_int_eq(has_blocks, 1);
}
END_TEST

// Тесты для конкретных фигур
START_TEST(test_init_figura_I) {
  figura_t f;
  init_figura_I(&f);

  ck_assert_int_eq(f.n, 4);
  ck_assert_int_eq(f.m, 1);
  ck_assert_int_eq(f.figura[0][0], 1);
  ck_assert_int_eq(f.figura[3][0], 1);
  ck_assert_int_eq(f.typeFigure, FIGURE_I);
}
END_TEST

START_TEST(test_init_figura_Q) {
  figura_t f;
  init_figura_Q(&f);

  ck_assert_int_eq(f.n, 2);
  ck_assert_int_eq(f.m, 2);
  ck_assert_int_eq(f.figura[0][0], 1);
  ck_assert_int_eq(f.figura[1][1], 1);
  ck_assert_int_eq(f.typeFigure, FIGURE_Q);
}
END_TEST

START_TEST(test_init_figura_S) {
  figura_t f;
  init_figura_S(&f);

  ck_assert_int_eq(f.n, 2);
  ck_assert_int_eq(f.m, 3);
  ck_assert_int_eq(f.figura[0][0], 0);
  ck_assert_int_eq(f.figura[0][1], 1);
  ck_assert_int_eq(f.figura[0][2], 1);
  ck_assert_int_eq(f.figura[1][0], 1);
  ck_assert_int_eq(f.figura[1][1], 1);
  ck_assert_int_eq(f.figura[1][2], 0);
  ck_assert_int_eq(f.typeFigure, FIGURE_S);
}
END_TEST

START_TEST(test_init_figura_Z) {
  figura_t f;
  init_figura_Z(&f);

  ck_assert_int_eq(f.n, 2);
  ck_assert_int_eq(f.m, 3);
  ck_assert_int_eq(f.figura[0][0], 1);
  ck_assert_int_eq(f.figura[0][1], 1);
  ck_assert_int_eq(f.figura[0][2], 0);
  ck_assert_int_eq(f.figura[1][0], 0);
  ck_assert_int_eq(f.figura[1][1], 1);
  ck_assert_int_eq(f.figura[1][2], 1);
  ck_assert_int_eq(f.typeFigure, FIGURE_Z);
}
END_TEST

// Тесты для spawn_new_figure
START_TEST(test_spawn_new_figure) {
  figura_t f1, f2;
  init_figura_L(&f1);
  init_figura_J(&f2);

  spawn_new_figure(&f1, &f2);

  // Проверяем, что f1 стала копией f2
  ck_assert_int_eq(f1.n, f2.n);
  ck_assert_int_eq(f1.m, f2.m);
  ck_assert_int_eq(f1.typeFigure, f2.typeFigure);
  ck_assert_int_eq(f1.figura[0][0], f2.figura[0][0]);
  ck_assert_int_eq(f1.figura[2][1], f2.figura[2][1]);
}
END_TEST

START_TEST(test_rotate) {
  GameInfo_t game;
  figura_t fnow, fnext;
  game.fnow = &fnow;
  game.fnext = &fnext;
  init_figura_L(&fnow);
  init_game(&game);

  int n = fnow.n;
  int m = fnow.m;

  rotate_figure(game.fnow, &game);
  ck_assert_int_eq(fnow.n, m);
  ck_assert_int_eq(fnow.m, n);
}
END_TEST

START_TEST(test_collision_left) {
  GameInfo_t game;
  figura_t fnow, fnext;
  game.fnow = &fnow;
  game.fnext = &fnext;
  init_figura_L(&fnow);
  init_game(&game);
  ck_assert_int_eq(collision_left(game.fnow, &game), 0);
}
END_TEST

START_TEST(test_collision_right) {
  GameInfo_t game;
  figura_t fnow, fnext;
  game.fnow = &fnow;
  game.fnext = &fnext;
  init_figura_L(&fnow);  // FIGUR_L
  init_game(&game);
  ck_assert_int_eq(collision_right(game.fnow, &game), 0);
}
END_TEST

Suite* tetris_suite(void) {
  Suite* s = suite_create("Tetris Backend");

  // Добавляем тесты
  TCase* tc_core = tcase_create("Core");
  tcase_add_test(tc_core, test_init_figura);
  tcase_add_test(tc_core, test_init_figura_I);
  tcase_add_test(tc_core, test_init_figura_Q);
  tcase_add_test(tc_core, test_init_figura_S);
  tcase_add_test(tc_core, test_init_figura_Z);
  tcase_add_test(tc_core, test_init_game);
  tcase_add_test(tc_core, test_rotate);
  tcase_add_test(tc_core, test_collision_left);
  tcase_add_test(tc_core, test_collision_right);
  suite_add_tcase(s, tc_core);

  TCase* tc_spawn = tcase_create("Spawn");
  tcase_add_test(tc_spawn, test_spawn_new_figure);
  suite_add_tcase(s, tc_spawn);

  TCase* tc_score = tcase_create("score");
  tcase_add_test(tc_score, test_score_calculation);
  tcase_add_test(tc_score, test_level_up);
  tcase_add_test(tc_score, test_shift_field);
  tcase_add_test(tc_score, test_write_read_score);
  suite_add_tcase(s, tc_score);

  return s;
}

int main(void) {
  int number_failed;
  Suite* s = tetris_suite();
  SRunner* sr = srunner_create(s);

  srunner_run_all(sr, CK_NORMAL);
  number_failed = srunner_ntests_failed(sr);
  srunner_free(sr);

  return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

#ifndef SRC_CLI_MAIN_CLI_H
#define SRC_CLI_MAIN_CLI_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../graph/s21_graph.h"
#include "../graph_algorithms/s21_graph_algorithms.h"

#define MAX_VERTICES 100
#define COLOR_RED "\033[1;31m"
#define COLOR_GREEN "\033[1;32m"
#define COLOR_YELLOW "\033[1;33m"
#define COLOR_BLUE "\033[1;34m"
#define COLOR_RESET "\033[0m"

#define MAX_FILENAME 256

static void run_algorithm(graph* g, tsm_result* (*algorithm)(graph*),
                          const char* filename, int iterations,
                          double* total_time, int visualize);
void compare_algorithms(graph* g, int iterations);

void visualize_graph(const char* dot_filename, const char* output_format);

void print_matrix(graph* g);

void print_path(int* path, int length);

void print_tree(graph* mst);

void print_tsm(tsm_result* res, int size);

void print_menu();

#endif  // SRC_CLI_MAIN_CLI_H
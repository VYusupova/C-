#include "main_cli.h"

/**
 * @brief Запускает алгоритм на графе и выводит результаты.
 *
 * @param g Указатель на граф.
 * @param algorithm Указатель на функцию алгоритма.
 * @param filename Имя файла для визуализации.
 * @param iterations Количество итераций.
 * @param total_time Указатель на переменную для хранения общего времени
 * выполнения.
 * @param visualize Флаг визуализации.
 */
static void run_algorithm(graph *g, tsm_result *(*algorithm)(graph *),
                          const char *filename, int iterations,
                          double *total_time, int visualize) {
  struct timespec start, end;
  tsm_result *res = NULL;
  tsm_result *best_res = NULL;
  double tmp_distance = 99999999;

  clock_gettime(CLOCK_MONOTONIC, &start);
  for (int i = 0; i < iterations; i++) {
    if (res) free_tsm_result(res);
    res = algorithm(g);
    if (res && tmp_distance > res->distance) {
      tmp_distance = res->distance;
      if (best_res) free_tsm_result(best_res);
      best_res = res;
      res = NULL;
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &end);

  *total_time =
      (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

  if (visualize && best_res) {
    FILE *f = fopen(filename, "w");
    if (f) {
      fprintf(f, "graph G {\n");
      for (int i = 0; i < g->size; i++) {
        int from = best_res->vertices[i];
        int to = best_res->vertices[i + 1];
        fprintf(f, "    %d -- %d [color=red, penwidth=2.0];\n", from, to);
      }
      fprintf(f, "}\n");
      fclose(f);
      visualize_graph(filename, "png");
      print_tsm(best_res, g->size);
    }
  }
  if (res) {
    free_tsm_result(res);
    res = NULL;
  }
  if (best_res)
    free_tsm_result(best_res);
  else
    printf("\n%sНет решения TSP!%s\n", COLOR_RED, COLOR_RESET);
}

/**
 * @brief Сравнивает алгоритмы на графе.
 *
 * @param g Указатель на граф.
 * @param iterations Количество итераций.
 */
void compare_algorithms(graph *g, int iterations) {
  double time_bf = 0, time_ant = 0, time_nn = 0;  // time_greedy = 0;

  printf("\nСравнение алгоритмов (%d итераций):\n", iterations);
  run_algorithm(g, bf_tsp, "tsp_bf.dot", iterations, &time_bf, 1);
  printf("Алгоритм прямого перебора:  %.4f сек.\n", time_bf);
  run_algorithm(g, solve_traveling_salesman_problem, "tsp_ant.dot", iterations,
                &time_ant, 1);
  printf("Муравьиный алгоритм:        %.4f сек.\n", time_ant);
  // run_algorithm(g, greedy_tsp, "tsp_greedy.dot", iterations, &time_greedy,
  // 1);
  // printf("Жадный алгоритм:            %.4f сек.\n", time_greedy);
  run_algorithm(g, nearest_neighbor_tsp, "tsp_nn.dot", iterations, &time_nn, 1);
  printf("Алгоритм блихайшего соседа: %.4f сек.\n", time_nn);
}

/**
 * @brief Визуализирует граф в формате DOT.
 *
 * @param dot_filename Имя файла DOT.
 * @param output_format Формат вывода.
 */
void visualize_graph(const char *dot_filename, const char *output_format) {
  static int counter = 0;
  char command[512];
  char output_file[256];

  snprintf(output_file, sizeof(output_file), "%s_%d", dot_filename, counter++);
  snprintf(command, sizeof(command), "dot -T%s -o%s.%s %s", output_format,
           output_file, output_format, dot_filename);

  if (system(command) == 0) {
    printf("\nОтрисовка графа сохранена в  %s.%s\n", output_file,
           output_format);
  } else {
    fprintf(stderr, "\nОшибка отрисовки графа %s\n", dot_filename);
  }
}

/**
 * @brief Выводит матрицу графа.
 *
 * @param g Указатель на граф.
 */
void print_matrix(graph *g) {
  const int size = g->size;
  printf("\n%sМатрица смежности:%s\n", COLOR_YELLOW, COLOR_RESET);

  printf("     ");
  for (int i = 0; i < size; i++) printf("%-4d", i + 1);

  printf("\n    ┌");
  for (int i = 0; i < size; i++) printf("────");
  printf("┐\n");

  for (int i = 0; i < size; i++) {
    printf("%2d │ ", i + 1);
    for (int j = 0; j < size; j++) {
      int val = g->matrix[i][j];
      if (val > 0) {
        printf("%s%-4d%s", COLOR_GREEN, val, COLOR_RESET);
      } else {
        printf("%-4d", 0);
      }
    }
    printf("│\n");
  }

  printf("    └");
  for (int i = 0; i < size; i++) printf("────");
  printf("┘\n");
}

/**
 * @brief Выводит путь.
 *
 * @param path Указатель на массив пути.
 * @param length Длина пути.
 */
void print_path(int *path, int length) {
  if (!path || length < 1) return;

  printf("\n%sПуть:%s ", COLOR_BLUE, COLOR_RESET);
  printf("%s%d%s", COLOR_GREEN, path[0], COLOR_RESET);

  for (int i = 1; i < length; i++) {
    printf(" → %s%d%s", COLOR_GREEN, path[i], COLOR_RESET);
  }
  printf("\n");
}

/**
 * @brief Выводит минимальное остовное дерево.
 *
 * @param mst Указатель на граф.
 */
void print_tree(graph *mst) {
  printf("\n%sМинимальное остовное дерево:%s\n", COLOR_YELLOW, COLOR_RESET);
  for (int i = 0; i < mst->size; i++) {
    for (int j = 0; j < mst->size; j++) {
      if (mst->matrix[i][j] > 0) {
        printf("%s%2d%s ——[%s%2d%s]—— %s%2d%s\n", COLOR_BLUE, i + 1,
               COLOR_RESET, COLOR_GREEN, mst->matrix[i][j], COLOR_RESET,
               COLOR_BLUE, j + 1, COLOR_RESET);
      }
    }
  }
}

/**
 * @brief Выводит результат задачи коммивояжера.
 *
 * @param res Указатель на результат.
 * @param size Размер результата.
 */
void print_tsm(tsm_result *res, int size) {
  printf("\n%sПуть:%s ", COLOR_YELLOW, COLOR_RESET);
  for (int i = 0; i <= size; i++) {
    printf("%s%d%s", COLOR_GREEN, res->vertices[i], COLOR_RESET);
    if (i < size) printf(" → ");
  }
  printf("\n%sРасстояние: %s%.2f%s\n", COLOR_YELLOW, COLOR_GREEN, res->distance,
         COLOR_RESET);
}

/**
 * @brief Выводит меню.
 */
void print_menu() {
  printf("\n%sГлавное меню:%s\n", COLOR_YELLOW, COLOR_RESET);
  printf("%s1.%s Загрузить граф из файла\n", COLOR_GREEN, COLOR_RESET);
  printf("%s2.%s Обход графа в ширину (BFS)\n", COLOR_GREEN, COLOR_RESET);
  printf("%s3.%s Обход графа в глубину (DFS)\n", COLOR_GREEN, COLOR_RESET);
  printf("%s4.%s Кратчайший путь между вершинами\n", COLOR_GREEN, COLOR_RESET);
  printf("%s5.%s Все кратчайшие пути\n", COLOR_GREEN, COLOR_RESET);
  printf("%s6.%s Минимальное остовное дерево (MST)\n", COLOR_GREEN,
         COLOR_RESET);
  printf("%s7.%s Задача коммивояжера (TSP). Муравьиный алгоритм\n", COLOR_GREEN,
         COLOR_RESET);
  printf("%s8.%s Сравнение алгоритмов\n", COLOR_GREEN, COLOR_RESET);
  printf("%s9.%s Показать граф\n", COLOR_GREEN, COLOR_RESET);
  printf("%s0.%s Выход\n", COLOR_RED, COLOR_RESET);
  printf("%sВыберите вариант: %s", COLOR_BLUE, COLOR_RESET);
}

int main() {
  graph *g = graph_create();
  graph *mst = NULL;
  double **paths_matrix = NULL;
  int loaded = 0;
  int option;
  char dot_file[MAX_FILENAME] = "graph.dot";

  while (1) {
    print_menu();
    if (scanf("%d", &option) != 1) {
      while (getchar() != '\n');
      printf("%sНеверный ввод!%s\n", COLOR_RED, COLOR_RESET);
      continue;
    }

    if (option == 0) break;

    switch (option) {
      case 1: {
        char filename[256];
        printf("%sВведите имя файла: %s", COLOR_BLUE, COLOR_RESET);
        scanf("%255s", filename);

        if (load_graph_from_file(g, filename)) {
          printf("%sОшибка загрузки графа!%s\n", COLOR_RED, COLOR_RESET);
        } else {
          loaded = 1;
          printf("%sГраф успешно загружен!%s\n", COLOR_GREEN, COLOR_RESET);
          print_matrix(g);
        }
        break;
      }

      case 2:
      case 3: {
        if (!loaded) {
          printf("%sГраф не загружен!%s\n", COLOR_RED, COLOR_RESET);
          break;
        }
        int start;
        struct timespec start_time, end_time;
        printf("%sВведите начальную вершину: %s", COLOR_BLUE, COLOR_RESET);
        if (scanf("%d", &start) != 1 || start < 1 || start > g->size) {
          printf("%sНекорректный ввод вершины!%s\n", COLOR_RED, COLOR_RESET);
          while (getchar() != '\n');
          break;
        }
        clock_gettime(CLOCK_MONOTONIC, &start_time);
        int *result = (option == 2) ? breadth_first_search(g, start)
                                    : depth_first_search(g, start);
        clock_gettime(CLOCK_MONOTONIC, &end_time);
        double total_time = (end_time.tv_sec - start_time.tv_sec) +
                            (end_time.tv_nsec - start_time.tv_nsec) / 1e9;
        if (result) {
          int count = 0;
          while (result[count] != -1) count++;
          print_path(result, count);
          printf("%sВремя выполнения: %s%.6f сек%s\n", COLOR_YELLOW,
                 COLOR_GREEN, total_time, COLOR_RESET);
          free(result);
        }
        break;
      }

      case 4: {
        if (!loaded) {
          printf("%sГраф не загружен!%s\n", COLOR_RED, COLOR_RESET);
          break;
        }
        int from, to;
        struct timespec start_time, end_time;

        printf("%sВведите начальную и конечную вершины: %s", COLOR_BLUE,
               COLOR_RESET);
        if (scanf("%d %d", &from, &to) != 2 || from < 1 || from > g->size ||
            to < 1 || to > g->size) {
          printf("%sНекорректный ввод вершины!%s\n", COLOR_RED, COLOR_RESET);
          while (getchar() != '\n');
          break;
        }

        clock_gettime(CLOCK_MONOTONIC, &start_time);
        double distance = get_shortest_path_between_vertices(g, from, to);
        clock_gettime(CLOCK_MONOTONIC, &end_time);
        double total_time = (end_time.tv_sec - start_time.tv_sec) +
                            (end_time.tv_nsec - start_time.tv_nsec) / 1e9;
        if (distance >= 0) {
          printf("%sКратчайшее расстояние: %s%.2f%s\n", COLOR_YELLOW,
                 COLOR_GREEN, distance, COLOR_RESET);
        } else {
          printf("%sПути не существует!%s\n", COLOR_RED, COLOR_RESET);
        }
        printf("%sВремя выполнения: %s%.6f сек%s\n", COLOR_YELLOW, COLOR_GREEN,
               total_time, COLOR_RESET);
        break;
      }

      case 5: {
        if (!loaded) {
          printf("%sГраф не загружен!%s\n", COLOR_RED, COLOR_RESET);
          break;
        }
        struct timespec start_time, end_time;
        clock_gettime(CLOCK_MONOTONIC, &start_time);
        paths_matrix = get_shortest_paths_between_all_vertices(g);
        clock_gettime(CLOCK_MONOTONIC, &end_time);
        double total_time = (end_time.tv_sec - start_time.tv_sec) +
                            (end_time.tv_nsec - start_time.tv_nsec) / 1e9;

        printf("\n%sВсе кратчайшие пути:%s\n", COLOR_YELLOW, COLOR_RESET);
        printf("     ");
        for (int i = 1; i <= g->size; i++) printf("%-8d", i);
        printf("\n    ┌");
        for (int i = 0; i < g->size; i++) printf("────────");
        printf("┐\n");

        for (int i = 1; i <= g->size; i++) {
          printf("%2d │ ", i);
          for (int j = 1; j <= g->size; j++) {
            if (paths_matrix[i][j] == INF)
              printf("%sINF     %s", COLOR_RED, COLOR_RESET);
            else
              printf("%-8.2f", paths_matrix[i][j]);
          }
          printf("│\n");
        }
        printf("    └");
        for (int i = 0; i < g->size; i++) printf("────────");
        printf("┘\n");

        printf("%sВремя выполнения: %s%.6f сек%s\n", COLOR_YELLOW, COLOR_GREEN,
               total_time, COLOR_RESET);
        free_shortest_paths_matrix(paths_matrix, g->size);
        break;
      }

      case 6: {
        if (!loaded) {
          printf("%sГраф не загружен!%s\n", COLOR_RED, COLOR_RESET);
          break;
        }
        struct timespec start_time, end_time;
        clock_gettime(CLOCK_MONOTONIC, &start_time);
        mst = get_least_spanning_tree(g);
        clock_gettime(CLOCK_MONOTONIC, &end_time);
        double total_time = (end_time.tv_sec - start_time.tv_sec) +
                            (end_time.tv_nsec - start_time.tv_nsec) / 1e9;
        if (mst) {
          export_graph_to_dot(mst, "mst.dot");
          visualize_graph("mst.dot", "png");
          // print_tree(mst); // УДОЛИТЬ вывод списка ребер
          print_matrix(mst);  // выводом результирующей матрицы смежности
          graph_free(mst);
        } else {
          printf("%sОстовного дерева не существует!%s\n", COLOR_RED,
                 COLOR_RESET);
        }
        printf("%sВремя выполнения: %s%.6f сек%s\n", COLOR_YELLOW, COLOR_GREEN,
               total_time, COLOR_RESET);
        break;
      }

      case 7: {
        if (!loaded) {
          printf("%sГраф не загружен!%s\n", COLOR_RED, COLOR_RESET);
          break;
        }
        double time_ant = 0;

        run_algorithm(g, solve_traveling_salesman_problem, "tsp_ant.dot", 1,
                      &time_ant, 1);
        break;
      }
      case 8: {
        if (!loaded) {
          printf("Граф не загружен!\n");
          break;
        }
        int iterations;
        printf("Введите количество итераций: ");
        if (scanf("%d", &iterations) != 1 || iterations < 1) {
          printf("Некорректный ввод!\n");
          break;
        }
        compare_algorithms(g, iterations);
        break;
      }

      case 9: {
        if (!loaded) {
          printf("%sГраф не загружен!%s\n", COLOR_RED, COLOR_RESET);
          break;
        }
        print_matrix(g);
        export_graph_to_dot(g, dot_file);
        visualize_graph(dot_file, "png");
        break;
      }

      default:
        printf("%sНекорректный вариант!%s\n", COLOR_RED, COLOR_RESET);
    }
  }

  graph_free(g);
  printf("%sЗавершение работы программы.%s\n", COLOR_GREEN, COLOR_RESET);
  return 0;
}
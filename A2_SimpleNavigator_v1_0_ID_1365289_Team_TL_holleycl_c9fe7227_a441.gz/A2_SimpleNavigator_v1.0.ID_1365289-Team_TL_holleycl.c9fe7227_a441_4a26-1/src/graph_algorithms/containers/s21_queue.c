#include "s21_queue.h"

/**
 * @brief Создает новую очередь
 * @return Указатель на созданную очередь
 */
queue *queue_create() {
  queue *q = malloc(sizeof(queue));
  q->front = q->rear = NULL;
  return q;
}

/**
 * @brief Добавляет элемент в очередь
 * @param q Указатель на очередь
 * @param value Значение элемента
 */
void queue_push(queue *q, int value) {
  queue_node *node = malloc(sizeof(queue_node));
  node->value = value;
  node->next = NULL;

  if (q->rear)
    q->rear->next = node;
  else
    q->front = node;
  q->rear = node;
}

/**
 * @brief Удаляет элемент из очереди
 * @param q Указатель на очередь
 * @return Значение удаленного элемента
 */
int queue_pop(queue *q) {
  if (!q->front) return -1;
  queue_node *temp = q->front;
  int value = temp->value;
  q->front = temp->next;

  if (!q->front) q->rear = NULL;
  free(temp);
  return value;
}

/**
 * @brief Возвращает значение первого элемента в очереди
 * @param q Указатель на очередь
 * @return Значение первого элемента
 */
int queue_front(const queue *q) { return q->front ? q->front->value : -1; }

/**
 * @brief Возвращает значение последнего элемента в очереди
 * @param q Указатель на очередь
 * @return Значение последнего элемента
 */
int queue_back(const queue *q) { return q->rear ? q->rear->value : -1; }

/**
 * @brief Освобождает память, занятую очередью
 * @param q Указатель на очередь
 */
void queue_free(queue *q) {
  while (q->front) queue_pop(q);
  free(q);
}
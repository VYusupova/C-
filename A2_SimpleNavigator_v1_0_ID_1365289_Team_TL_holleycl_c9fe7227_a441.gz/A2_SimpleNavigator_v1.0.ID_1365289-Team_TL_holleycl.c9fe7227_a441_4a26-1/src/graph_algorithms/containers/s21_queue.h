#ifndef SRC_GRAPH_ALGORITHMS_CONTAINERS_S21_QUEUE_H
#define SRC_GRAPH_ALGORITHMS_CONTAINERS_S21_QUEUE_H

#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Структура узла очереди
 */
typedef struct queue_node {
  int value;               /**< Значение узла */
  struct queue_node *next; /**< Указатель на следующий узел */
} queue_node;

/**
 * @brief Структура очереди
 */
typedef struct {
  queue_node *front; /**< Указатель на первый узел */
  queue_node *rear;  /**< Указатель на последний узел */
} queue;

queue *queue_create();
void queue_push(queue *q, int value);
int queue_pop(queue *q);
int queue_front(const queue *q);
int queue_back(const queue *q);
void queue_free(queue *q);

#endif  // SRC_GRAPH_ALGORITHMS_CONTAINERS_S21_QUEUE_H

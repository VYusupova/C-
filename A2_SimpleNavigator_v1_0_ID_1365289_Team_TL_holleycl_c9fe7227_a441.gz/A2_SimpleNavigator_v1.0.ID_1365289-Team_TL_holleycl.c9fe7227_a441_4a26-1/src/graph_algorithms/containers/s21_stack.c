#include "s21_stack.h"

/**
 * @brief Создает новый стек
 * @return Указатель на созданный стек
 */
stack *stack_create() {
  stack *s = malloc(sizeof(stack));
  if (s) s->top = NULL;
  return s;
}

/**
 * @brief Добавляет элемент в стек
 * @param s Указатель на стек
 * @param value Значение элемента
 */
void stack_push(stack *s, int value) {
  stack_node *node = malloc(sizeof(stack_node));
  node->value = value;
  node->next = s->top;
  s->top = node;
}

/**
 * @brief Удаляет элемент из стека
 * @param s Указатель на стек
 * @return Значение удаленного элемента
 */
int stack_pop(stack *s) {
  if (!s->top) return -1;
  stack_node *temp = s->top;
  int value = temp->value;
  s->top = temp->next;
  free(temp);
  return value;
}

/**
 * @brief Возвращает значение верхнего элемента стека
 * @param s Указатель на стек
 * @return Значение верхнего элемента
 */
int stack_top(const stack *s) { return s->top ? s->top->value : -1; }

/**
 * @brief Освобождает память, занятую стеком
 * @param s Указатель на стек
 */
void stack_free(stack *s) {
  while (s->top) stack_pop(s);
  free(s);
}
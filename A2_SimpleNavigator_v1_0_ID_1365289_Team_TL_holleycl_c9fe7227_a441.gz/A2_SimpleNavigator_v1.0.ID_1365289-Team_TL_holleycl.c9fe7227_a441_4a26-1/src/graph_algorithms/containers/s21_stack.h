#ifndef SRC_GRAPH_ALGORITHMS_CONTAINERS_S21_STACK_H
#define SRC_GRAPH_ALGORITHMS_CONTAINERS_S21_STACK_H

#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Структура узла стека
 */
typedef struct stack_node {
  int value;               /**< Значение узла */
  struct stack_node *next; /**< Указатель на следующий узел */
} stack_node;

/**
 * @brief Структура стека
 */
typedef struct {
  stack_node *top; /**< Указатель на вершину стека */
} stack;

stack *stack_create();
void stack_push(stack *s, int value);
int stack_pop(stack *s);
int stack_top(const stack *s);
void stack_free(stack *s);

#endif  // SRC_GRAPH_ALGORITHMS_CONTAINERS_S21_STACK_H

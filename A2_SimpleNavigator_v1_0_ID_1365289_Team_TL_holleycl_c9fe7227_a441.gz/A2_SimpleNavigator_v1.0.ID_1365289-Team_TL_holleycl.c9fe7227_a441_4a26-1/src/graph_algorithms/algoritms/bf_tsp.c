#include "../s21_graph_algorithms.h"

/**
 * @brief Обмен значений двух переменных.
 * @param a Указатель на первую переменную.
 * @param b Указатель на вторую переменную.
 */
void swap(int *a, int *b) {
  int tmp = *a;
  *a = *b;
  *b = tmp;
}

/**
 * @brief Обратный порядок элементов в массиве.
 * @param array Массив.
 * @param size Размер массива.
 */
void reverse(int *array, int size) {
  for (int i = 0; i < size / 2; i++) swap(&array[i], &array[size - i - 1]);
}

/**
 * @brief Генерация следующей перестановки.
 * @param array Массив.
 * @param size Размер массива.
 * @return 1, если перестановка была сгенерирована, 0 - иначе.
 */
int next_permutation(int *array, int size) {
  int i = size - 2;
  while (i >= 0 && array[i] >= array[i + 1]) i--;
  if (i < 0) return 0;

  int j = size - 1;
  while (array[j] <= array[i]) j--;
  swap(&array[i], &array[j]);

  reverse(array + i + 1, size - i - 1);
  return 1;
}

/**
 * @brief Решение задачи коммивояжера с помощью полного перебора алгоритма.
 * @note Алгоритм находит точное решение TSP (гарантированно минимальный путь),
 * путем генерации всех возможных
 * * перестановок вершин. Для каждой перестановки вычисляет длину цикла.
 * * Сохраняет путь с минимальной длиной. Сложность O(n!) - экспоненциальная
 * @param graph Указатель на граф.
 * @return Результат решения задачи коммивояжера.
 */
tsm_result *bf_tsp(graph *graph) {
  if (!graph || graph->size < 2) return NULL;

  tsm_result *result = malloc(sizeof(tsm_result));
  result->vertices = malloc((graph->size + 1) * sizeof(int));
  result->distance = INF;

  int *path = malloc((graph->size) * sizeof(int));
  for (int i = 0; i < graph->size; i++) path[i] = i + 1;

  // Перебор всех перестановок вершин
  do {
    double current_dist = 0;
    int valid = 1;

    // Проверяем путь path[0] → path[1] → ... → path[n-1] → path[0]
    for (int i = 0; i < graph->size; i++) {
      int from = path[i] - 1;
      int to = path[(i + 1) % graph->size] - 1;

      // Проверка связности: Если ребро между вершинами отсутствует
      // (matrix[from][to] == 0), путь считается недопустимым.
      if (graph->matrix[from][to] == 0) {
        valid = 0;
        break;
      }
      current_dist += graph->matrix[from][to];
    }

    if (valid && current_dist < result->distance) {
      result->distance = current_dist;
      memcpy(result->vertices, path, graph->size * sizeof(int));
      result->vertices[graph->size] = path[0];
    }
  } while (next_permutation(path, graph->size));

  free(path);
  if (result->distance == INF) {
    free(result->vertices);
    free(result);
    return NULL;
  }
  return result;
}

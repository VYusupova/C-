#include "s21_graph_algorithms.h"

/**
 * @brief Освобождение памяти, выделенной под матрицу кратчайших путей.
 * @param matrix Матрица кратчайших путей.
 * @param size Размер матрицы.
 */
void free_shortest_paths_matrix(double **matrix, int size) {
  if (!matrix) return;
  for (int i = 1; i <= size; i++) free(matrix[i]);
  free(matrix);
}

/**
 * @brief Освобождение памяти, выделенной под результат решения задачи
 * коммивояжера.
 * @param result Результат решения задачи коммивояжера.
 */
void free_tsm_result(tsm_result *result) {
  if (!result) return;

  if (result->vertices) {
    free(result->vertices);
    result->vertices = NULL;
  }

  free(result);
}

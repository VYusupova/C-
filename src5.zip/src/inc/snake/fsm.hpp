#ifndef FSM_HPP
#define FSM_HPP


//#include <cmath>
//#include <new>
//#include <stdexcept>
//#include <vector>
//#include <utility>
#include "../defines.h"
#include "../BrickGame.h"
//#include "../Brick_frontend.h"
#include "backend.hpp"

namespace s21 {
class fsm {
public:
  static void snake_userInput(UserAction_t action, bool hold) ;
  static GameInfo_t snake_updateCurrentState() ;
 void snake_cleanup(void);
        //UserAction_t get_signal(int user_input);
  static void sigact(UserAction_t *userAct, GameInfo_t *gamestats, fsm_state_t *state);

  static void started(GameInfo_t *game);
  static void moved(const UserAction_t *userAct, GameInfo_t *game);
  static void Move();

  void NewGame();
  //void GameOver();
  void QuitGame();
  void SetPause();
  void UnSetPause();
  int ProcessGameTimer();
};
}

#endif

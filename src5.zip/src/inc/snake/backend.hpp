#ifndef BACKEND_H
#define BACKEND_H


//#include <cmath>
//#include <new>
//#include <stdexcept>
//#include <cstddef>
#include <vector>
#include <utility>
#include "../BrickGame.h"
#include "../defines.h"

namespace s21 {
class snake {
	public:
	  snake();
	  ~snake();
	  void move();
	  bool checkCollision() const;
	  void changeDirection(int newDir);
	  snake(const snake&) = delete;
	  snake& operator=(const snake&) = delete;

		const std::pair<int, int>& getHead() const { return body.front(); }
    const std::pair<int, int>& getTail() const { return body.back(); }
    const std::vector<std::pair<int, int>>& getBody() const { return body; }
    size_t getLength() const { return body.size(); }
    GameInfo_t getGameState() const { return game; }
    void setPause(bool pause) { game.pause = pause; }
    void resetGame();

	private:
    void updateGameField();
	  void FreeGameMemory(GameInfo_t *game);
		std::vector<std::pair<int, int>> body;  // Сегменты змейки (x, y)
	  int direction;  // 0: вверх, 1: вправо, 2: вниз, 3: влево
		const int max_snake_length = FIELD_M * FIELD_N;
		void snake_init();
	  void SpawnFruit();
	  void FruitEat();
		GameInfo_t game;
		bool needsToGrow = false;
};
}

#endif

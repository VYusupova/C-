#include <iostream>
#include <vector>
#include "../inc/BrickGame.h"
#include "../../inc/snake/backend.hpp"
#include <algorithm>
#include <random>

namespace s21 {

snake::snake() {
    game.field = new int*[FIELD_N];
    for (int i = 0; i < FIELD_N; ++i) {
      game.field[i] = new int[FIELD_M]{0};
    }
    game.next = NULL;
    game.pause = 0;
    game.score = 0;
    game.speed = 1;
    game.high_score = 0;

    snake_init();
    SpawnFruit();
    updateGameField();
}

void snake::FreeGameMemory(GameInfo_t* game) {
	if(!game || !game->field) {
		return;
	}

	for(int i = 0; i < FIELD_N; i++) {
		delete[] game->field[i];
	}
	delete[] game->field;
	game->field = nullptr;
}

snake::~snake() {
	FreeGameMemory(&game);
}

void snake::snake_init() {
  body.clear();
	int head_x = FIELD_M / 2;
	int head_y = FIELD_N / 2;
	body.emplace_back(head_x, head_y);  // Голова
  for (int i = 0; i < 4; ++i) {
    body.emplace_back(head_x - i, head_y);
  }
  direction = 1;
  
  updateGameField();
}

void snake::move() {
  if (body.empty()) return;
  if (!game.pause) {
	  auto newHead = body.front();
	  switch(direction) {
	  	case 0:
	  		newHead.second--;
	  	  break;
	  	case 1:
	  		newHead.first++;
	  	  break;
	  	case 2:
	  		newHead.second++;
	  	  break;
	  	case 3:
	  		newHead.first--;
	  	  break;
	  }

    if (newHead.first < 0 || newHead.first >= FIELD_M || newHead.second < 0 || newHead.second >= FIELD_N) {
      game.pause = true;
      return;
    }

     if (std::find(body.begin(), body.end(), newHead) != body.end()) {
        // Game Over логика
        game.pause = true;
        return;
    }

	  body.insert(body.begin(), newHead);

     // Проверить съедание фрукта
    if (game.field[newHead.second][newHead.first] == 3) FruitEat();

	  if(!needsToGrow) {
	  	body.pop_back();
	  } else {
	  	needsToGrow = false;
	  }
  }
  updateGameField();
}

bool snake::checkCollision() const {
	const auto head = body.front();
	return std::any_of(body.begin() + 1, body.end(), [&head](const auto &segment){ //умнейшая разработка алгоритмов
		return head == segment;
	});
	return head.first < 0 || head.first >= FIELD_N || head.second < 0 || head.second >= FIELD_M;
}

void snake::changeDirection(int newDir) {
	if(abs(newDir - direction) != 2) {
		direction = newDir;
	}
}

void snake::SpawnFruit() {
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> x_dist(0, FIELD_M - 1);
  std::uniform_int_distribution<int> y_dist(0, FIELD_N - 1);

  int fruit_x, fruit_y;
  do {
    fruit_x = x_dist(gen);
    fruit_y = y_dist(gen);
  } while (game.field[fruit_y][fruit_x] != 0);

  game.field[fruit_y][fruit_x] = 3;
}

void snake::FruitEat() {
	game.score += 1;
	needsToGrow = true;
	if(game.speed != 10) {
	game.speed = 1 + game.score / 5;
	}
	SpawnFruit();
}

void snake::updateGameField() {
    for (int i = 0; i < FIELD_N; ++i) {
        for (int j = 0; j < FIELD_M; ++j) {
          if(game.field[i][j] == 3) continue;
            game.field[i][j] = 0;
        }
    }
    
    for (size_t i = 0; i < body.size(); ++i) {
        int x = body[i].first;
        int y = body[i].second;
        if (x >= 0 && x < FIELD_M && y >= 0 && y < FIELD_N) {
            game.field[y][x] = (i == 0) ? 4 : 20;  // голова = 1, тело = 2
        }
    }
}

void snake::resetGame() {
// Очистка текущего состояния
    for (int i = 0; i < FIELD_N; ++i) {
        for (int j = 0; j < FIELD_M; ++j) {
            game.field[i][j] = 0;
        }
    }
    
    game.pause = 0;
    game.score = 0;
    game.speed = 1;
    
    // Переинициализация змейки
    snake_init();
    SpawnFruit();
    updateGameField();}
}

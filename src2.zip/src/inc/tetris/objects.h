#ifndef OBJECTS_H
#define OBJECTS_H

#include "../defines.h"

typedef struct {
  int n;
  int m;
  int x;
  int y;
  int figura[FSIZE][FSIZE];
  int typeFigure;
} figura_t;  // параметры фигуры

typedef enum {
  FIGURE_Q = 1,
  FIGURE_I,
  FIGURE_S,
  FIGURE_Z,
  FIGURE_L,
  FIGURE_J,
  FIGURE_T
} list_figures_t;

#endif

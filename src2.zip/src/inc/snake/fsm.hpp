#include <cmath>
#include <new>
#include <stdexcept>
#include <vector>
#include <utility>
#include "../defines.h"
#include "../BrickGame.h"
#include "../Brick_frontend.h"
#include "backend.hpp"

namespace s21 {
class fsm {
public:
	UserAction_t get_signal(int user_input);
	void fsm::sigact(const UserAction_t *userAct, GameInfo_t *gamestats, fsm_state_t *state);
  void Move();
  void NewGame();
  void GameOver();
  void QuitGame();
  void SetPause();
  void UnSetPause();
  int ProcessGameTimer();
	brick_state_t getState() const { return state; }
private:
	fsm_state_t *state;
	UserAction_t *userAct;
	GameInfo_t *game;
}
}


#include "../../inc/snake/fsm.hpp"


namespace s21 {

static s21::snake snake_instance;

UserAction_t fsm::get_signal(int user_input) {
        UserAction_t action;

  switch (user_input) {
    case 72:
      action = Up;
      break;
    case 40:
      action = Down;
      break;
    case 75:
      action = Left;
      break;
    case 77:
      action = Right;
      break;
    case ESCAPE:
      action = Terminate;
      break;
    case ENTER_KEY:
      action = Start;
      break;
    case SPACE:
      action = Action;
      break;
    case PAUSE_p:
      action = Pause;
      break;
    case PAUSE_P:
      action = Pause;
      break;
    default:
      break;
  }
  return action;
}

void fsm::sigact(const UserAction_t *userAct, GameInfo_t *gamestats, fsm_state_t *state) {
    switch (*state) {
        case START:
            if (*userAct == Start) {
                started(gamestats);
                *state = MOVING;
            }
            break;
        case MOVING:
            moved(userAct, gamestats);
            break;
        case GAMEOVER:
            if (*userAct == Start) {
                started(gamestats);
                *state = MOVING;
            }
            //GameOver();
            break;
        default:
            break;
    }
}

void fsm::started(GameInfo_t *game) {
    // Реинициализация игры
    snake_instance.resetGame();  // нужен экземпляр snake
    game->score = 0;
    game->level = 1;
    game->speed = 1;
    game->pause = 0;
}

void fsm::moved(const UserAction_t *userAct, GameInfo_t *game) {
    switch (*userAct) {
        case Up:
            snake_instance.changeDirection(0);
            break;
        case Right:
            snake_instance.changeDirection(1);
            break;
        case Down:
            snake_instance.changeDirection(2);
            break;
        case Left:
            snake_instance.changeDirection(3);
            break;
        case Pause:
            game->pause = !game->pause;
            break;
        default:
            break;
    }

    if (!game->pause) {
      snake_instance.move();
        *game = snake_instance.getGameState();  // обновить состояние игры
    }
}

}

#ifndef SRC_SCORE_C
#define SRC_SCORE_C

#include "../../inc/tetris/tetris.h"

void score(GameInfo_t *game) {
  int lines = 0;
  for (int y = FIELD_N - 1; y >= 0; y--) {
    int cell = 0;
    for (int x = FIELD_M - 1; x >= 0; x--) {
      if (game->field[y][x] == 0)
        break;
      else
        cell++;
    }
    if (cell == 10) {
      lines++;
      shift_field(game, y);
      y++;
    }
  }
  if (lines == 1) game->score += 100;
  if (lines == 2) game->score += 300;
  if (lines == 3) game->score += 700;
  if (lines == 4) game->score += 1500;
  level_up(game);
}

void level_up(GameInfo_t *game) {
  if (game->level == 10) return;
  int level = game->score / 600;
  if (game->level < level) {
    game->level = level;
    game->speed = game->speed * 0.9;
  }
}

void shift_field(GameInfo_t *game, int y) {
  for (int y1 = y; y1 >= 1; y1--) {
    for (int x = 0; x < FIELD_M; x++)
      game->field[y1][x] = game->field[y1 - 1][x];
    for (int x = 0; x < FIELD_M; x++) game->field[0][x] = 0;
  }
}

void write_score(const GameInfo_t *game) {
  if (game->high_score < game->score) {
    FILE *f = fopen(MAX_SCORE, "w");
    fprintf(f, "%d", game->score);
    fclose(f);
  }
}

int read_score() {
  FILE *f = fopen(MAX_SCORE, "r");
  if (f == NULL) {
    return 0;
  }
  int max_score;
  fscanf(f, "%d", &max_score);
  fclose(f);
  return max_score;
}

#endif

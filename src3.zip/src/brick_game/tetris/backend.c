#include "../../inc/tetris/tetris_backend.h"

void init_figura(figura_t *f) {
  for (int i = 0; i < FSIZE; i++)
    for (int j = 0; j < FSIZE; j++) f->figura[i][j] = 0;

  int fig = rand() % 8;
  while (fig == 0) fig = rand() % 8;
  switch (fig) {
    case FIGURE_Q:
      init_figura_Q(f);
      break;
    case FIGURE_I:
      init_figura_I(f);
      break;
    case FIGURE_S:
      init_figura_S(f);
      break;
    case FIGURE_Z:
      init_figura_Z(f);
      break;
    case FIGURE_L:
      init_figura_L(f);
      break;
    case FIGURE_J:
      init_figura_J(f);
      break;
    default:
      init_figura_T(f);
      break;
  }
  f->typeFigure = (int)(rand() % COLOR_PINK) + 1;
  while (f->typeFigure < 0) {
    f->typeFigure = (int)(rand() % COLOR_PINK) + 1;
  }
}

void init_figura_Q(figura_t *f) {
  f->n = 2;
  f->m = 2;
  f->figura[0][0] = 1, f->figura[0][1] = 1;
  f->figura[1][0] = 1, f->figura[1][1] = 1;
  f->typeFigure = FIGURE_Q;
}

void init_figura_I(figura_t *f) {
  f->n = 4;
  f->m = 1;
  f->figura[0][0] = 1;
  f->figura[1][0] = 1;
  f->figura[2][0] = 1;
  f->figura[3][0] = 1;
  f->typeFigure = FIGURE_I;
}

void init_figura_S(figura_t *f) {
  f->n = 2;
  f->m = 3;
  f->figura[0][0] = 0, f->figura[0][1] = 1, f->figura[0][2] = 1;
  f->figura[1][0] = 1, f->figura[1][1] = 1, f->figura[1][2] = 0;
  f->typeFigure = FIGURE_S;
}

void init_figura_Z(figura_t *f) {
  f->n = 2;
  f->m = 3;
  f->figura[0][0] = 1, f->figura[0][1] = 1, f->figura[0][2] = 0;
  f->figura[1][0] = 0, f->figura[1][1] = 1, f->figura[1][2] = 1;
  f->typeFigure = FIGURE_Z;
}

void init_figura_L(figura_t *f) {
  f->n = 3;
  f->m = 2;
  f->figura[0][0] = 1, f->figura[0][1] = 0;
  f->figura[1][0] = 1, f->figura[1][1] = 0;
  f->figura[2][0] = 1, f->figura[2][1] = 1;
  f->typeFigure = FIGURE_L;
}

void init_figura_J(figura_t *f) {
  f->n = 3;
  f->m = 2;
  f->figura[0][0] = 0, f->figura[0][1] = 1;
  f->figura[1][0] = 0, f->figura[1][1] = 1;
  f->figura[2][0] = 1, f->figura[2][1] = 1;
  f->typeFigure = FIGURE_J;
}

void init_figura_T(figura_t *f) {
  f->n = 2;
  f->m = 3;
  f->figura[0][0] = 0, f->figura[0][1] = 1, f->figura[0][2] = 0;
  f->figura[1][0] = 1, f->figura[1][1] = 1, f->figura[1][2] = 1;
  f->typeFigure = FIGURE_T;
}

void init_game(GameInfo_t *state, figura_t *fnow, figura_t *fnext) {
  tetris_field_free(state);
  state->next = NULL;
  state->field = (int **)malloc(FIELD_N * sizeof(int *));
  for (int i = 0; i < FIELD_N; i++) {
    state->field[i] = (int *)malloc(FIELD_M * sizeof(int));
    for (int j = 0; j < FIELD_M; j++) {
      state->field[i][j] = 0;
    }
  }
  state->level = 0;
  state->score = 0;
  state->high_score = read_score();
  state->speed = SPEED;
  state->pause = 0;
  init_start_position(fnow, START_X, START_Y);
  init_start_position(fnext, R_NEXT_X, R_NEXT_Y);
}

void tetris_field_free(GameInfo_t *state) {
  if (state->field != NULL) {
    for (int i = 0; i < FIELD_N; i++) {
      if (state->field[i] != NULL) {
        free(state->field[i]);
        state->field[i] = NULL;
      }
    }
    free(state->field);
    state->field = NULL;
  }
}

void init_start_position(figura_t *f, int x, int y) {
  f->x = x;
  f->y = y;
}

void figura_game_field(GameInfo_t *game, const figura_t *fnow) {
  for (int y = fnow->y, k = 0; y < FIELD_N && k < fnow->n; y++, k++)
    for (int x = fnow->x, l = 0; x < FIELD_M && l < fnow->m; x++, l++)
      if (fnow->figura[k][l]) game->field[y][x] = fnow->typeFigure;
}

void spawn_new_figure(figura_t *fnow, figura_t *fnext) {
  fnow->x = START_X;
  fnow->y = START_Y;
  fnow->n = fnext->n;
  fnow->m = fnext->m;
  fnow->typeFigure = fnext->typeFigure;
  for (int i = 0; i < FSIZE; i++)
    for (int j = 0; j < FSIZE; j++) fnow->figura[i][j] = fnext->figura[i][j];
}

int check_collision_field(const GameInfo_t *state, int down, int left,
                          const figura_t *fnow) {
  int result = SUCCESS;
  for (int i = fnow->y + down, k = 0; i < FIELD_N && k < fnow->n; i++, k++)
    for (int j = fnow->x + left, l = 0; j < FIELD_M && l < fnow->m; j++, l++)
      if (state->field[i][j] != 0 && fnow->figura[k][l] == 1) result = ERROR;
  return result;
}

int collision_left(const figura_t *f, const GameInfo_t *state) {
  int result = SUCCESS;
  if ((f->x) <= 0)
    result = ERROR;
  else if (check_collision_field(state, 0, -1, f))
    result = ERROR;
  return result;
}

int collision_right(const figura_t *f, const GameInfo_t *state) {
  int result = SUCCESS;
  if (f->x + f->m >= (FIELD_M)) result = ERROR;
  if (check_collision_field(state, 0, 1, f)) result = ERROR;
  return result;
}

int collision_up(const figura_t *f) {
  if (f->y <= START_Y) return ERROR;
  return SUCCESS;
}

int collision_down(const figura_t *f, const GameInfo_t *state) {
  int result = SUCCESS;
  if ((f->y + f->n) >= (FIELD_N))
    result = ERROR;
  else if (check_collision_field(state, 1, 0, f))
    result = ERROR;
  return result;
}

void rotate_figure(figura_t *f, const GameInfo_t *state) {
  figura_t new;
  new.x = f->x;
  new.y = f->y;
  new.n = f->m;
  new.m = f->n;
  new.typeFigure = f->typeFigure;
  for (int i = 0; i < new.n; i++)
    for (int j = 0; j < new.m; j++)
      new.figura[i][j] = f->figura[j][new.n - 1 - i];
  if (new.x + new.m > (FIELD_M)) new.x = FIELD_M - new.m;
  if (new.x < 0) new.x = 0;
  if (!collision_down(&new, state) && !check_collision_field(state, 0, 1, f) &&
      !check_collision_field(state, 0, -1, f)) {
    for (int i = 0; i < new.n; i++)
      for (int j = 0; j < new.m; j++) f->figura[i][j] = new.figura[i][j];
    f->n = new.n;
    f->m = new.m;
    f->x = new.x;
    f->y = new.y;
  }
}


#include <assert.h>
#include <check.h>
#include <time.h>

#include "../brick_game/tetris/include/back.h"
#include "../brick_game/tetris/include/controller.h"
#include "tetris_private_func.h"

void sleepMilliseconds(unsigned int milliseconds) {
  clock_t start_time = clock();
  while ((clock() - start_time) * 1000 / CLOCKS_PER_SEC < milliseconds)
    ;
}

void setup(void) {
  NewGame(GetData());
}

void teardown(void)
{
  QuitGame(GetData());
}

START_TEST(check_lines_and_score) {
  TetrisGameData* data = GetData();
  for (int j = 0; j < 10; j++) data->game_info.field[22][j] = 1;
  CheckLinesAddScore(data);
  ck_assert_int_eq(data->game_info.score, 100);
  ck_assert_int_eq(data->game_info.field[22][0], 0);
  
}

START_TEST(check_lines_and_score2) {
  TetrisGameData* data = GetData();
  for (int j = 0; j < 10; j++) {
    data->game_info.field[22][j] = 1;
    data->game_info.field[21][j] = 1;
  }
  CheckLinesAddScore(data);
  ck_assert_int_eq(data->game_info.score, 300);
  ck_assert_int_eq(data->game_info.field[22][0], 0);
  
}

START_TEST(check_lines_and_score3) {
  TetrisGameData* data = GetData();
  for (int j = 0; j < 10; j++) {
    data->game_info.field[22][j] = 1;
    data->game_info.field[21][j] = 1;
    data->game_info.field[20][j] = 1;
  }
  CheckLinesAddScore(data);
  ck_assert_int_eq(data->game_info.score, 700);
  ck_assert_int_eq(data->game_info.field[22][0], 0);
  
}

START_TEST(check_lines_and_score4) {
  setup();
  TetrisGameData* data = GetData();
  for (int j = 0; j < 10; j++) {
    data->game_info.field[22][j] = 1;
    data->game_info.field[21][j] = 1;
    data->game_info.field[20][j] = 1;
    data->game_info.field[19][j] = 1;
    
  }
  CheckLinesAddScore(data);
  ck_assert_int_eq(data->game_info.score, 1500);
  ck_assert_int_eq(data->game_info.field[22][0], 0);
  
}

START_TEST(timer1) {
  setup();
  struct timeval current = GetData()->last_tick;
  sleepMilliseconds(1000);
  ck_assert(current.tv_sec <= GetData()->last_tick.tv_sec);
  
}

START_TEST(timer2) {
  setup();
  SetPause(GetData());
  sleepMilliseconds(1000);
  ck_assert_int_eq(ProcessTimer(GetData()), 0);
  
}

START_TEST(timer3) {
  setup();
  struct timeval current = GetData()->last_tick;
  GetData()->game_info.speed = 10;
  GetGameData();
  sleepMilliseconds(150);
  ck_assert_int_eq(ProcessTimer(GetData()), 1);
  ck_assert(current.tv_usec != GetData()->last_tick.tv_usec);
  
}

START_TEST(new_game_reset) {
  setup();
  TetrisGameData* data = GetData();

  data->game_info.field[5][3] = 1;
  data->game_info.score = 500;
  data->game_info.speed = 5;

  NewGame(data);

  ck_assert_int_eq(data->game_info.field[5][3], 0);
  ck_assert_int_eq(data->game_info.score, 0);
  ck_assert_int_eq(data->game_info.speed, 1);
  ck_assert_int_eq(data->figure_controller->corner_x, 3);
  
}

START_TEST(move_figure_collision) {
  setup();
  TetrisGameData* data = GetData();

  for (int i = 0; i < 4; i++) data->figure_controller->figure_field[2][i] = 1;
  data->figure_controller->corner_y = 20;

  int result = MoveFigure(data, Down);
  ck_assert_int_eq(result, 1);

  data->figure_controller->corner_x = 0;
  MoveFigure(data, Left);
  ck_assert_int_eq(data->figure_controller->corner_x, 0);
  
}

START_TEST(rotate_figure_wall_kick) {
  setup();
  TetrisGameData* data = GetData();

  data->figure_controller->figure_field[1][2] = 1;
  data->figure_controller->figure_field[2][2] = 1;
  data->figure_controller->figure_field[3][2] = 1;
  data->figure_controller->figure_field[3][3] = 1;
  data->figure_controller->corner_x = 7;

  RotateFigure(data);
  ck_assert_int_lt(data->figure_controller->corner_x, 7);
  
}

START_TEST(place_and_show_figure) {
  setup();
  TetrisGameData* data = GetData();
  for (int i = 0; i < 5; i++) {
    memset(data->figure_controller->figure_field[i], 0, 5 * sizeof(int));
  }
  data->figure_controller->figure_field[0][2] = 1;
  data->figure_controller->figure_field[0][3] = 1;
  data->figure_controller->figure_field[1][2] = 1;
  data->figure_controller->figure_field[1][3] = 1;

  PlaceFigure(data->game_info.field, data->figure_controller);
  ck_assert_int_eq(data->game_info.field[0][5], 1);
  GetData()->figure_controller->corner_y = 3;
  ShowFigure(data->copy_to_share.field, data->figure_controller);
  ck_assert_int_eq(data->copy_to_share.field[0][5], 1);
  
}

START_TEST(game_over) {
  setup();
  TetrisGameData* data = GetData();

  GameOver(data);
  ck_assert_int_eq(data->game_info.pause, 1);
  for (int i = 0; i < 23; i++) {
    for (int j = 0; j < 10; j++)
      ck_assert_int_eq(data->game_info.field[i][j], 1);
  }
  
}

START_TEST(spawn_next_figure) {
  setup();
  TetrisGameData* data = GetData();

  NewNextFigure(data);
  int sum_prev = 0;
  for (int i = 0; i < 5; i++)
    for (int j = 0; j < 5; j++) sum_prev += data->game_info.next[i][j];

  SpawnFigure(data);
  int sum_current = 0;
  for (int i = 0; i < 5; i++)
    sum_current += data->figure_controller->figure_field[i][2];

  ck_assert_int_gt(sum_prev, 0);
  ck_assert_int_gt(sum_current, 0);
  
}

START_TEST(test_top_line_fill) {
  setup();
  TetrisGameData* data = GetData();

  for (int i = 0; i < 10; i++) data->game_info.field[3][i] = 1;

  ck_assert_int_eq(TopLineFill(data), 1);
  
}

START_TEST(high_score_io) {
  setup();
  TetrisGameData* data = GetData();

  data->game_info.high_score = 9999;
  SaveHighScore(data);

  int loaded_score = 0;
  LoadHighScore(&loaded_score);
  ck_assert_int_eq(loaded_score, 9999);
  
}

START_TEST(get_controller_state) {
  setup();
  GameState* state = GetControllerState();
  ck_assert_ptr_nonnull(state);
  ck_assert_int_eq(*state, START);
  
}

START_TEST(start_new_game) {
  setup();
  TetrisGameData* data = GetData();
  StartNewGame();
  ck_assert_int_eq(*GetControllerState(), PLAY);
  ck_assert_int_eq(data->figure_controller->corner_x, 3);
  ck_assert_int_eq(data->figure_controller->corner_y, 0);
  
}

START_TEST(get_game_data_play_state) {
  setup();
  *GetControllerState() = PLAY;
  GameInfo_t info = GetGameData();
  ck_assert_ptr_nonnull(info.field);
  
}


START_TEST(process_pause_unpause) {
  setup();
  *GetControllerState() = PAUSE;
  ProcessPause(Pause);
  ck_assert_int_eq(*GetControllerState(), PLAY);
  
}

START_TEST(process_pause_start) {
  setup();
  *GetControllerState() = PAUSE;
  ProcessPause(Start);
  ck_assert_int_eq(*GetControllerState(), PLAY);
  
}

START_TEST(process_action_move) {
  setup();
  *GetControllerState() = PLAY;
  ProcessAction(Left, false);
  ck_assert_int_eq(GetData()->figure_controller->corner_x, 2);
  
}

START_TEST(process_action_rotate) {
  setup();
  *GetControllerState() = PLAY;
  int old_x = GetData()->figure_controller->corner_x;
  ProcessAction(Action,false);
  ck_assert_int_eq(GetData()->figure_controller->corner_x, old_x);
  
}

START_TEST(process_input_start_state) {
  setup();
  *GetControllerState() = START;
  ProcessInput(Start);
  ck_assert_int_eq(*GetControllerState(), PLAY);
  
}

START_TEST(process_input_play_state) {
  *GetControllerState() = PLAY;
  ProcessInput(Left);
  ck_assert_int_eq(GetData()->figure_controller->corner_x, 2);
  
}

START_TEST(process_input_pause_state) {
  *GetControllerState() = PAUSE;
  ProcessInput(Pause);
  ck_assert_int_eq(*GetControllerState(), PLAY);
  
}

START_TEST(handle_collision_place_and_check) {
  TetrisGameData* data = GetData();
  *GetControllerState() = PLAY;
  data->figure_controller->corner_y = 20;
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      data->figure_controller->figure_field[i][j] = 0;
    }
  }
  data->figure_controller->figure_field[2][2] = 1;
  data->figure_controller->figure_field[2][3] = 1;
  data->figure_controller->figure_field[2][4] = 1;
  HandleCollision();
  ck_assert_int_eq(data->game_info.field[22][5], 1);
  ck_assert_int_eq(data->game_info.field[22][6], 1);
  
}

START_TEST(handle_collision_game_over) {
  TetrisGameData* data = GetData();
  *GetControllerState() = PLAY;
  for (int j = 0; j < 10; j++) {
    data->game_info.field[3][j] = 1;
  }
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      data->figure_controller->figure_field[i][j] = 0;
    }
  }
  data->figure_controller->figure_field[2][2] = 1;
  HandleCollision();
  ck_assert_int_eq(*GetControllerState(), GAME_OVER);
  ck_assert_int_eq(data->game_info.pause, 1);
  for (int i = 0; i < 23; i++) {
    for (int j = 0; j < 10; j++) {
      ck_assert_int_eq(data->game_info.field[i][j], 1);
    }
  }
  
}

START_TEST(handle_collision_line_completion) {
  TetrisGameData* data = GetData();
  *GetControllerState() = PLAY;
  for (int j = 0; j < 9; j++) {
    data->game_info.field[22][j] = 1;
  }
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      data->figure_controller->figure_field[i][j] = 0;
    }
  }
  data->figure_controller->figure_field[2][2] = 1;
  data->figure_controller->corner_y = 20;
  data->figure_controller->corner_x = 7;
  HandleCollision();
  for (int j = 0; j < 10; j++) {
    ck_assert_int_eq(data->game_info.field[22][j], 0);
  }
  ck_assert_int_eq(data->game_info.score, 100);
  
}
START_TEST(process_action) {
  setup();
  ProcessInput(Start);
  ProcessInput(Pause);
  ck_assert_int_eq(GetGameData().pause, 1);
  ck_assert_int_eq(*GetControllerState(), PAUSE);
  ProcessInput(Start);
  ck_assert_int_eq(*GetControllerState(), PLAY);
  
}


Suite* game_suite(void) {
  Suite* s;
  TCase* tc_core;

  s = suite_create("tetris");
  tc_core = tcase_create("Core");
  tcase_add_checked_fixture(tc_core, setup, teardown);
  tcase_add_test(tc_core, check_lines_and_score);
  tcase_add_test(tc_core, check_lines_and_score2);
  tcase_add_test(tc_core, check_lines_and_score3);
  tcase_add_test(tc_core, check_lines_and_score4);
  tcase_add_test(tc_core, timer1);
  tcase_add_test(tc_core, timer2);
  tcase_add_test(tc_core, timer3);
  tcase_add_test(tc_core, new_game_reset);
  tcase_add_test(tc_core, move_figure_collision);
  tcase_add_test(tc_core, rotate_figure_wall_kick);
  tcase_add_test(tc_core, place_and_show_figure);
  tcase_add_test(tc_core, game_over);
  tcase_add_test(tc_core, spawn_next_figure);
  tcase_add_test(tc_core, test_top_line_fill);
  tcase_add_test(tc_core, high_score_io);
  tcase_add_test(tc_core, get_controller_state);
  tcase_add_test(tc_core, start_new_game);
  tcase_add_test(tc_core, get_game_data_play_state);
  tcase_add_test(tc_core, process_pause_unpause);
  tcase_add_test(tc_core, process_pause_start);
  tcase_add_test(tc_core, process_action_move);
  tcase_add_test(tc_core, process_action_rotate);
  tcase_add_test(tc_core, process_input_start_state);
  tcase_add_test(tc_core, process_input_play_state);
  tcase_add_test(tc_core, process_input_pause_state);
  tcase_add_test(tc_core, handle_collision_place_and_check);
  tcase_add_test(tc_core, handle_collision_game_over);
  tcase_add_test(tc_core, handle_collision_line_completion);
  tcase_add_test(tc_core, process_action);
  suite_add_tcase(s, tc_core);

  return s;
}

int main(void) {
  int number_failed = 0;
  Suite* list[] = {game_suite(), NULL};

  for (int i = 0; list[i] != NULL; i++) {
    SRunner* sr = srunner_create(list[i]);
    srunner_run_all(sr, CK_NORMAL);
    number_failed += srunner_ntests_failed(sr);
    srunner_free(sr);
  }

  return (number_failed == 0) ? 0 : 1;
}
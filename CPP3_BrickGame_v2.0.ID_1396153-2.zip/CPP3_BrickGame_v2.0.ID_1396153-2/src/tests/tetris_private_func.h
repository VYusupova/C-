#ifndef TETRIS_PRIVATE_FUNC_H
#define TETRIS_PRIVATE_FUNC_H
#include "../brick_game/tetris/include/back.h"
#include "../brick_game/tetris/include/controller.h"
#include "../include/library_spec.h"
#include "tetris_private_func.h"
// back_test.h
void LoadHighScore(int* high_score);
GameState* GetControllerState();
void HandleTerminate();
void StartNewGame();
void HandleCollision();
void ProcessPause(UserAction_t input);
void ProcessAction(UserAction_t input, bool hold);
#endif  // TETRIS_PRIVATE_FUNC_H
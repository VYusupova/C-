#include "include/snake.h"

#include <fstream>

/**
 * @file snake.cpp
 * @brief объект игры змейка
 */

/**
 * @brief конструктор
 */
s21::Snake::Snake() {
  try {
    game_data_.field = new int*[k_height];
    for (int i = 0; i < k_height; ++i) {
      game_data_.field[i] = new int[k_width]{0};
    }
    copy_to_share_.field = new int*[k_height];
    for (int i = 0; i < k_height; ++i) {
      copy_to_share_.field[i] = new int[k_width]{0};
    }
    game_data_.next = NULL;
    game_data_.pause = 0;
    game_data_.score = 0;
    game_data_.speed = 1;
    game_data_.high_score = 0;
    shared_data_ptr_ = NULL;
    copy_to_share_.next = NULL;
    LoadHighScore();
  } catch (...) {
    throw std::runtime_error("Error in snake constructor");
  }
}

/**
 * @brief очистка памяти
 */
void s21::Snake::FreeGameMemory(GameInfo_t* game_info) {
  if (!game_info || !game_info->field) {
    return;
  }

  for (int i = 0; i < 20; ++i) {
    delete[] game_info->field[i];
  }
  delete[] game_info->field;
  game_info->field = nullptr;
}

/**
 * @brief деструктор
 */
s21::Snake::~Snake() {
  FreeGameMemory(&game_data_);
  FreeGameMemory(&copy_to_share_);
}

/**
 * @brief обработка таймера для движения змейки
 */
int s21::Snake::ProcessGameTimer() {
  if (game_data_.pause) {
    return 0;
  }
  auto elapsed = std::chrono::steady_clock::now() - last_tick_time_;
  std::chrono::milliseconds drop_delay = {};
  drop_delay = std::chrono::milliseconds(1000 / game_data_.speed);

  if (elapsed < drop_delay) {
    return 0;
  } else {
    last_tick_time_ = std::chrono::steady_clock::now();
    return 1;
  }
}

/**
 * @brief сбор данных для передачи в контроллер
 */
GameInfo_t s21::Snake::CollectGameInfo() {
  if (game_data_.field != NULL && copy_to_share_.field != NULL) {
    copy_to_share_.score = game_data_.score;
    copy_to_share_.high_score = game_data_.high_score;
    copy_to_share_.pause = game_data_.pause;
    copy_to_share_.speed = game_data_.speed;
    shared_data_ptr_ = &copy_to_share_;
    if (ProcessGameTimer()) {
      Move();
    }
    for (int i = 0; i < k_height; ++i)
      for (int j = 0; j < k_width; ++j) {
        if (game_data_.field[i][j])
          copy_to_share_.field[i][j] = 1;
        else
          copy_to_share_.field[i][j] = 0;
      }
    return *shared_data_ptr_;
  } else {
    return copy_to_share_;
  }
}

/**
 * @brief создание змейки
 */
void s21::Snake::InitializeSnake() {
  int head_x = k_width / 2;
  int head_y = k_height / 2;
  head_position_ = {head_x, head_y};
  current_direction_ = {1, 0};
  new_direction_ = current_direction_;
  snake_body_.clear();

  for (int i = 0; i < 4; ++i) {
    snake_body_.push_back({head_x - i, head_y});
  }

  snake_length_ = 4;

  int segment_value = 1;
  for (const auto& segment : snake_body_) {
    if (segment.first >= 0 && segment.first < k_width && segment.second >= 0 &&
        segment.second < k_height) {
      game_data_.field[segment.second][segment.first] = segment_value;
    }
    segment_value = 2;
  }
}

/**
 * @brief обработка съеденной фрукта, увеличение счета и длины змейки
 */
void s21::Snake::HandleFruitEaten(int fruit_x, int fruit_y) {
  if (snake_body_.front().first == fruit_x &&
      snake_body_.front().second == fruit_y) {
    this->is_growing_ = true;
    game_data_.score += 1;
    if (game_data_.score > game_data_.high_score) {
      game_data_.high_score = game_data_.score;
    }
    game_data_.speed = 1 + game_data_.score / 5;
    if (game_data_.speed > 10) {
      game_data_.speed = 10;
    }
    SpawnFruit();
  }
}

/**
 * @brief создание фрукта
 */
void s21::Snake::SpawnFruit() {
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> x_dist(0, k_width - 1);
  std::uniform_int_distribution<int> y_dist(0, k_height - 1);

  int fruit_x, fruit_y;
  do {
    fruit_x = x_dist(gen);
    fruit_y = y_dist(gen);
  } while (game_data_.field[fruit_y][fruit_x] != 0);

  game_data_.field[fruit_y][fruit_x] = 3;
}

/**
 * @brief установка направления движения
 */
void s21::Snake::SetDirection(int x, int y) {
  if (current_direction_.first == -x && current_direction_.second == -y) {
    new_direction_ = current_direction_;
  } else {
    new_direction_ = {x, y};
  }
}

/**
 * @brief движение змейки
 */
void s21::Snake::Move() {
  if (game_data_.pause) {
    return;
  }
  int new_x = head_position_.first + new_direction_.first;
  int new_y = head_position_.second + new_direction_.second;
  if (new_x < 0 || new_x >= k_width || new_y < 0 || new_y >= k_height) {
    GameOver();
  } else if (game_data_.field[new_y][new_x] == 2) {
    GameOver();
  } else {
    snake_body_.push_front({new_x, new_y});

    if (game_data_.field[new_y][new_x] == 3) {
      HandleFruitEaten(new_x, new_y);
    }

    if (!is_growing_) {
      auto tail = snake_body_.back();
      game_data_.field[tail.second][tail.first] = 0;
      snake_body_.pop_back();
    } else {
      is_growing_ = false;
      snake_length_++;
    }

    int segment_value = 1;
    for (const auto& segment : snake_body_) {
      if (segment.first >= 0 && segment.first < k_width &&
          segment.second >= 0 && segment.second < k_height) {
        game_data_.field[segment.second][segment.first] = segment_value;
      }
      segment_value = 2;
    }

    current_direction_ = new_direction_;
    head_position_ = {new_x, new_y};
  }
}

/**
 * @brief выход из игры, закрытие приложения
 */
void s21::Snake::QuitGame() {
  SaveHighScore();
  FreeGameMemory(&game_data_);
  FreeGameMemory(&copy_to_share_);
  game_data_.pause = 1;
  copy_to_share_.pause = 1;
  shared_data_ptr_ = NULL;
}

/**
 * @brief сохранение рекорда
 */
void s21::Snake::SaveHighScore() {
  if (game_data_.field && game_data_.score >= game_data_.high_score) {
    game_data_.high_score = game_data_.score;
    std::ofstream outfile("snake_score.txt");
    if (!outfile) {
      throw std::runtime_error("Failed to open file for saving high score");
    }
    outfile << game_data_.high_score;
  }
}

/**
 * @brief загрузка рекорда
 */
void s21::Snake::LoadHighScore() {
  std::ifstream infile("snake_score.txt");
  if (infile) {
    infile >> game_data_.high_score;
  } else {
    game_data_.high_score = 0;
  }
}

/**
 * @brief создание новой игры с установкой начальных значений
 */
void s21::Snake::NewGame() {
  for (int i = 0; i < k_height; ++i) {
    std::fill(this->game_data_.field[i],
              this->game_data_.field[i] + this->k_width, 0);
  }
  snake_body_.clear();
  this->snake_length_ = 0;
  this->game_data_.score = 0;
  this->game_data_.speed = 1;
  this->game_data_.pause = 0;
  InitializeSnake();
  SpawnFruit();
  this->last_tick_time_ = std::chrono::steady_clock::now();
}

/**
 * @brief завершение игры
 */
void s21::Snake::GameOver() {
  SetPause();
  if (game_data_.field != NULL)
    for (int i = 0; i < k_height; ++i) {
      std::fill(this->game_data_.field[i], this->game_data_.field[i] + k_width,
                1);
    }
  snake_body_.clear();
  SaveHighScore();
}

/**
 * @brief установка паузы
 */
void s21::Snake::SetPause() { this->game_data_.pause = 1; }

/**
 * @brief снятие паузы
 */
void s21::Snake::UnSetPause() { this->game_data_.pause = 0; }

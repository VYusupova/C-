#ifndef SNAKE_CLASS_H
#define SNAKE_CLASS_H

/**
 * @file snake.h
 * @brief класс объекта игры
 */

#include <chrono>
#include <list>
#include <random>

#include "../../../include/library_spec.h"
namespace s21 {
class Snake {
 private:
  std::chrono::time_point<std::chrono::steady_clock> last_tick_time_;
  std::mt19937 random_generator;
  const int kMaxSnakeLength = 200;
  GameInfo_t game_data_;
  GameInfo_t copy_to_share_;
  std::list<std::pair<int, int>> snake_body_;
  std::pair<int, int> head_position_ = {0, 0};
  std::pair<int, int> tail_position = {0, 0};
  std::pair<int, int> new_direction_;
  std::pair<int, int> current_direction_;

  int snake_length_ = 0;
  bool is_growing_ = false;
  void InitializeSnake();
  void SpawnFruit();
  void FreeGameMemory(GameInfo_t* game_info);
  void SaveHighScore();
  void LoadHighScore();
  void HandleFruitEaten(int fruit_x, int fruit_y);
  GameInfo_t* shared_data_ptr_;

 public:
  const int k_height = 20;
  const int k_width = 10;
  Snake();
  ~Snake();
  Snake(const Snake&) = delete;
  Snake& operator=(const Snake&) = delete;

  GameInfo_t CollectGameInfo();

  void SetDirection(int x, int y);
  void Move();
  void NewGame();
  void GameOver();
  void QuitGame();
  void SetPause();
  void UnSetPause();
  int ProcessGameTimer();
};
};  // namespace s21

#endif  // SNAKE_CLASS_H
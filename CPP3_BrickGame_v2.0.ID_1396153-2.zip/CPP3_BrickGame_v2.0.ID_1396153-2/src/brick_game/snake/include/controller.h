#ifndef CONTROLLER_H
#define CONTROLLER_H

/**
 * @file controller.h
 * @brief класс движка игры, управляющего состояем бэкенда и общающегося с view
 */

#include <chrono>

#include "../../../include/library_spec.h"
#include "snake.h"
namespace s21 {
class GameEngine {
 public:
  GameEngine()
      : current_state_(State::kStart),
        move_direction(Right),
        last_update_time_(std::chrono::steady_clock::now()){};

  void HandleInput(UserAction_t action);
  static GameEngine& GetGameEngine();
  GameInfo_t GetGameInfo();

 private:
  void StartNewGame();
  static Snake& GetSnake();
  enum class State { kStart, kPlay, kPause, kQuit } current_state_;
  UserAction_t move_direction;
  std::chrono::time_point<std::chrono::steady_clock> last_update_time_;
  void ProcessDirectionInput(UserAction_t action);
};
}  // namespace s21

#endif  // CONTROLER_H
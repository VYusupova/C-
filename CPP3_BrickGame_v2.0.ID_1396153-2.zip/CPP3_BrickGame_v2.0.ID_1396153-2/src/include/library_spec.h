#ifndef LIBRARY_SPEC_H
#define LIBRARY_SPEC_H
#include <stdbool.h>

/**
 * @file  library_spec.h
 * @brief спецификация библиотеки
 */
typedef struct {
  int **field;
  int **next;
  int score;
  int high_score;
  int speed;
  int pause;
} GameInfo_t;

typedef enum {
  Start,
  Pause,
  Terminate,
  Left,
  Right,
  Up,
  Down,
  Action
} UserAction_t;

#ifdef __cplusplus
extern "C" {
#endif
GameInfo_t updateCurrentState();
void userInput(UserAction_t action, bool hold);
#ifdef __cplusplus
}
#endif

#endif  // LIBRARY_SPEC_H
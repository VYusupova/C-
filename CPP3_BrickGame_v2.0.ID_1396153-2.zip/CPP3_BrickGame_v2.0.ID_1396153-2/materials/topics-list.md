# Topics list

Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will study:

- Finite-state machines;
- Working with matrices;
- Working with files;
- Working with GUI library;
- MVC pattern.

Now that you know what awaits you in this project, you can slowly begin to study the topics listed above.😇
